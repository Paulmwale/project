"""
Authentication, roles and persistence for the dashboard.

Storage: a small SQLite database (default: data/app.db, override with the
APP_DB_PATH environment variable). Tables:
  users      - accounts, salted PBKDF2 password hashes, role, status, lockout
  activity   - audit trail (logins, failures, admin actions)
  estimates  - every cost estimate a user calculates
  settings   - admin-controlled settings (default tariff, registration on/off)

Roles:
  user  - can log in, run cost estimates, see their own estimate history
  admin - everything a user can do, plus the full forecasting dashboard and the
          Admin Panel (user management, activity log, all estimates, settings)

Passwords are never stored in plain text: PBKDF2-HMAC-SHA256, 200,000 iterations,
per-user random salt, constant-time comparison. After 5 consecutive failed
logins an account is locked for 5 minutes.

NOTE: on Streamlit Community Cloud the filesystem is ephemeral, so the SQLite
file resets when the app restarts/redeploys. For a persistent deployment point
APP_DB_PATH at a mounted volume or swap this module's connection for a hosted
database (the SQL used here is deliberately plain).
"""

import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timezone

_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
DB_PATH = os.environ.get("APP_DB_PATH", os.path.join(_DATA_DIR, "app.db"))

PBKDF2_ITERATIONS = 200_000
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_SECONDS = 300
MIN_PASSWORD_LEN = 8
USERNAME_RE = re.compile(r"^[a-z0-9_.-]{3,30}$")

DEFAULT_SETTINGS = {
    "default_tariff": "2.50",       # ZMW per kWh, indicative
    "allow_registration": "1",      # 1 = visitors may self-register as 'user'
}

# Fallback bootstrap admin, used ONLY when no admin credentials are supplied via
# environment variables / Streamlit secrets. The account is flagged so the
# holder is forced to choose a new password at first login.
FALLBACK_ADMIN_USERNAME = "admin"
FALLBACK_ADMIN_PASSWORD = "ChangeMe-2026!"


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


@contextmanager
def _conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


def _hash_password(password: str, salt_hex: str) -> str:
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), PBKDF2_ITERATIONS)
    return dk.hex()


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

def init_db(admin_username: str | None = None, admin_password: str | None = None) -> None:
    """Create tables, default settings and (if no users exist) the first admin."""
    with _conn() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                username        TEXT PRIMARY KEY,
                full_name       TEXT NOT NULL,
                organisation    TEXT NOT NULL DEFAULT '',
                password_hash   TEXT NOT NULL,
                salt            TEXT NOT NULL,
                role            TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
                active          INTEGER NOT NULL DEFAULT 1,
                must_change     INTEGER NOT NULL DEFAULT 0,
                failed_attempts INTEGER NOT NULL DEFAULT 0,
                locked_until    REAL NOT NULL DEFAULT 0,
                created_at      TEXT NOT NULL,
                last_login      TEXT
            );
            CREATE TABLE IF NOT EXISTS activity (
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                ts       TEXT NOT NULL,
                username TEXT NOT NULL,
                action   TEXT NOT NULL,
                detail   TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS estimates (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                ts            TEXT NOT NULL,
                username      TEXT NOT NULL,
                facility      TEXT NOT NULL,
                horizon_days  INTEGER NOT NULL,
                loadshedding  INTEGER NOT NULL,
                tariff        REAL NOT NULL,
                own_avg_kwh   REAL NOT NULL DEFAULT 0,
                total_kwh     REAL NOT NULL,
                peak_kwh      REAL NOT NULL,
                total_cost    REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS review_requests (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                ts            TEXT NOT NULL,
                username      TEXT NOT NULL,
                facility_name TEXT NOT NULL,
                facility_type TEXT NOT NULL,
                location      TEXT NOT NULL DEFAULT '',
                contact       TEXT NOT NULL,
                subject       TEXT NOT NULL,
                message       TEXT NOT NULL,
                estimate_id   INTEGER,
                status        TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','in_progress','resolved')),
                admin_reply   TEXT NOT NULL DEFAULT '',
                replied_at    TEXT,
                replied_by    TEXT,
                reply_unread  INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        for k, v in DEFAULT_SETTINGS.items():
            con.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (k, v))

        has_users = con.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0

    if not has_users:
        if admin_username and admin_password:
            create_user(admin_username, admin_password, "Administrator", role="admin", must_change=False,
                        _skip_policy=True)
        else:
            create_user(FALLBACK_ADMIN_USERNAME, FALLBACK_ADMIN_PASSWORD, "Administrator", role="admin",
                        must_change=True, _skip_policy=True)


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

def _row_to_user(row) -> dict:
    return {
        "username": row["username"],
        "full_name": row["full_name"],
        "organisation": row["organisation"],
        "role": row["role"],
        "active": bool(row["active"]),
        "must_change": bool(row["must_change"]),
        "created_at": row["created_at"],
        "last_login": row["last_login"],
    }


def validate_password(password: str) -> str | None:
    if len(password) < MIN_PASSWORD_LEN:
        return f"Password must be at least {MIN_PASSWORD_LEN} characters."
    if password.isalpha() or password.isdigit():
        return "Password must mix letters with numbers or symbols."
    return None


def create_user(username: str, password: str, full_name: str, role: str = "user",
                organisation: str = "", must_change: bool = False, _skip_policy: bool = False):
    """Returns (ok, message)."""
    username = (username or "").strip().lower()
    full_name = (full_name or "").strip()
    if not USERNAME_RE.match(username):
        return False, "Username must be 3–30 characters: letters, numbers, dot, dash or underscore."
    if not full_name:
        return False, "Please enter a full name."
    if role not in ("user", "admin"):
        return False, "Invalid role."
    if not _skip_policy:
        problem = validate_password(password)
        if problem:
            return False, problem
    salt = secrets.token_hex(16)
    try:
        with _conn() as con:
            con.execute(
                "INSERT INTO users(username, full_name, organisation, password_hash, salt, role, must_change, created_at) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (username, full_name, organisation.strip(), _hash_password(password, salt), salt, role,
                 int(must_change), _now()),
            )
    except sqlite3.IntegrityError:
        return False, "That username is already taken."
    return True, f"Account '{username}' created."


def authenticate(username: str, password: str):
    """Returns (user_dict | None, message). Handles lockout and inactive accounts."""
    username = (username or "").strip().lower()
    generic = "Incorrect username or password."
    with _conn() as con:
        row = con.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if row is None:
            # Burn comparable time so unknown usernames aren't distinguishable by timing.
            _hash_password(password or "", "00" * 16)
            return None, generic
        if row["locked_until"] > time.time():
            mins = int((row["locked_until"] - time.time()) // 60) + 1
            return None, f"Too many failed attempts. Try again in about {mins} minute(s)."
        ok = hmac.compare_digest(_hash_password(password or "", row["salt"]), row["password_hash"])
        if not ok:
            attempts = row["failed_attempts"] + 1
            locked_until = time.time() + LOCKOUT_SECONDS if attempts >= MAX_FAILED_ATTEMPTS else 0
            con.execute("UPDATE users SET failed_attempts = ?, locked_until = ? WHERE username = ?",
                        (0 if locked_until else attempts, locked_until, username))
            con.execute("INSERT INTO activity(ts, username, action, detail) VALUES (?,?,?,?)",
                        (_now(), username, "login_failed", f"attempt {attempts}"))
            return None, generic
        if not row["active"]:
            return None, "This account has been deactivated. Contact an administrator."
        con.execute("UPDATE users SET failed_attempts = 0, locked_until = 0, last_login = ? WHERE username = ?",
                    (_now(), username))
        con.execute("INSERT INTO activity(ts, username, action, detail) VALUES (?,?,?,?)",
                    (_now(), username, "login", ""))
        fresh = con.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        return _row_to_user(fresh), "OK"


def get_user(username: str) -> dict | None:
    with _conn() as con:
        row = con.execute("SELECT * FROM users WHERE username = ?", (username.strip().lower(),)).fetchone()
    return _row_to_user(row) if row else None


def list_users() -> list[dict]:
    with _conn() as con:
        rows = con.execute("SELECT * FROM users ORDER BY role, username").fetchall()
    return [_row_to_user(r) for r in rows]


def change_password(username: str, new_password: str, must_change: bool = False):
    problem = validate_password(new_password)
    if problem:
        return False, problem
    salt = secrets.token_hex(16)
    with _conn() as con:
        con.execute(
            "UPDATE users SET password_hash = ?, salt = ?, must_change = ?, failed_attempts = 0, locked_until = 0 "
            "WHERE username = ?",
            (_hash_password(new_password, salt), salt, int(must_change), username.strip().lower()),
        )
    return True, "Password updated."


def verify_password(username: str, password: str) -> bool:
    with _conn() as con:
        row = con.execute("SELECT salt, password_hash FROM users WHERE username = ?",
                          (username.strip().lower(),)).fetchone()
    if row is None:
        return False
    return hmac.compare_digest(_hash_password(password or "", row["salt"]), row["password_hash"])


def _active_admin_count(con) -> int:
    return con.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]


def set_active(username: str, active: bool):
    username = username.strip().lower()
    with _conn() as con:
        row = con.execute("SELECT role, active FROM users WHERE username = ?", (username,)).fetchone()
        if row is None:
            return False, "User not found."
        if not active and row["role"] == "admin" and _active_admin_count(con) <= 1:
            return False, "You can't deactivate the only active administrator."
        con.execute("UPDATE users SET active = ? WHERE username = ?", (int(active), username))
    return True, f"Account '{username}' {'activated' if active else 'deactivated'}."


def set_role(username: str, role: str):
    username = username.strip().lower()
    if role not in ("user", "admin"):
        return False, "Invalid role."
    with _conn() as con:
        row = con.execute("SELECT role, active FROM users WHERE username = ?", (username,)).fetchone()
        if row is None:
            return False, "User not found."
        if row["role"] == "admin" and role != "admin" and row["active"] and _active_admin_count(con) <= 1:
            return False, "You can't demote the only active administrator."
        con.execute("UPDATE users SET role = ? WHERE username = ?", (role, username))
    return True, f"'{username}' is now {role}."


def delete_user(username: str):
    username = username.strip().lower()
    with _conn() as con:
        row = con.execute("SELECT role, active FROM users WHERE username = ?", (username,)).fetchone()
        if row is None:
            return False, "User not found."
        if row["role"] == "admin":
            return False, "Administrator accounts can't be deleted — demote the account first."
        con.execute("DELETE FROM users WHERE username = ?", (username,))
    return True, f"Account '{username}' deleted."


# ---------------------------------------------------------------------------
# Activity, estimates, settings
# ---------------------------------------------------------------------------

def log_activity(username: str, action: str, detail: str = "") -> None:
    with _conn() as con:
        con.execute("INSERT INTO activity(ts, username, action, detail) VALUES (?,?,?,?)",
                    (_now(), username, action, detail))


def get_activity(limit: int = 500) -> list[dict]:
    with _conn() as con:
        rows = con.execute("SELECT ts, username, action, detail FROM activity ORDER BY id DESC LIMIT ?",
                           (limit,)).fetchall()
    return [dict(r) for r in rows]


def save_estimate(username: str, facility: str, horizon_days: int, loadshedding: bool, tariff: float,
                  own_avg_kwh: float, total_kwh: float, peak_kwh: float, total_cost: float) -> int:
    """Stores an estimate and returns its id (used as the PDF reference number)."""
    with _conn() as con:
        cur = con.execute(
            "INSERT INTO estimates(ts, username, facility, horizon_days, loadshedding, tariff, own_avg_kwh, "
            "total_kwh, peak_kwh, total_cost) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (_now(), username, facility, horizon_days, int(loadshedding), tariff, own_avg_kwh,
             round(total_kwh, 1), round(peak_kwh, 1), round(total_cost, 2)),
        )
        return cur.lastrowid


def get_estimates(username: str | None = None, limit: int = 1000) -> list[dict]:
    with _conn() as con:
        if username:
            rows = con.execute("SELECT * FROM estimates WHERE username = ? ORDER BY id DESC LIMIT ?",
                               (username.strip().lower(), limit)).fetchall()
        else:
            rows = con.execute("SELECT * FROM estimates ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def get_setting(key: str) -> str:
    with _conn() as con:
        row = con.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else DEFAULT_SETTINGS.get(key, "")


def set_setting(key: str, value: str) -> None:
    with _conn() as con:
        con.execute("INSERT INTO settings(key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, str(value)))


# ---------------------------------------------------------------------------
# Facility review requests (user -> admin messaging)
# ---------------------------------------------------------------------------

REQUEST_STATUSES = ("new", "in_progress", "resolved")


def create_review_request(username: str, facility_name: str, facility_type: str, location: str, contact: str,
                          subject: str, message: str, estimate_id: int | None = None):
    """Returns (ok, message_or_id)."""
    facility_name, contact = (facility_name or "").strip(), (contact or "").strip()
    subject, message = (subject or "").strip(), (message or "").strip()
    if not facility_name or not contact or not subject or not message:
        return False, "Please fill in the facility name, contact details, subject and message."
    if len(message) > 3000 or len(subject) > 150:
        return False, "Message is too long (max 3000 characters; subject max 150)."
    with _conn() as con:
        cur = con.execute(
            "INSERT INTO review_requests(ts, username, facility_name, facility_type, location, contact, subject, "
            "message, estimate_id) VALUES (?,?,?,?,?,?,?,?,?)",
            (_now(), username.strip().lower(), facility_name, facility_type, (location or "").strip(), contact,
             subject, message, estimate_id),
        )
        return True, cur.lastrowid


def list_review_requests(username: str | None = None, status: str | None = None) -> list[dict]:
    q, args = "SELECT * FROM review_requests", []
    clauses = []
    if username:
        clauses.append("username = ?"); args.append(username.strip().lower())
    if status:
        clauses.append("status = ?"); args.append(status)
    if clauses:
        q += " WHERE " + " AND ".join(clauses)
    q += " ORDER BY id DESC"
    with _conn() as con:
        return [dict(r) for r in con.execute(q, args).fetchall()]


def count_open_requests() -> int:
    with _conn() as con:
        return con.execute("SELECT COUNT(*) FROM review_requests WHERE status = 'new'").fetchone()[0]


def update_review_request(request_id: int, status: str, reply: str, admin_username: str):
    if status not in REQUEST_STATUSES:
        return False, "Invalid status."
    reply = (reply or "").strip()
    with _conn() as con:
        row = con.execute("SELECT admin_reply FROM review_requests WHERE id = ?", (request_id,)).fetchone()
        if row is None:
            return False, "Request not found."
        reply_changed = reply != row["admin_reply"]
        if reply_changed and reply and status == "new":
            status = "in_progress"   # replying means it is being handled
        if reply_changed and reply:
            con.execute(
                "UPDATE review_requests SET status = ?, admin_reply = ?, replied_at = ?, replied_by = ?, "
                "reply_unread = 1 WHERE id = ?", (status, reply, _now(), admin_username, request_id))
        else:
            con.execute("UPDATE review_requests SET status = ? WHERE id = ?", (status, request_id))
    return True, "Request updated." + (" Reply sent to the user." if reply_changed and reply else "")


def count_unread_replies(username: str) -> int:
    with _conn() as con:
        return con.execute("SELECT COUNT(*) FROM review_requests WHERE username = ? AND reply_unread = 1",
                           (username.strip().lower(),)).fetchone()[0]


def mark_replies_read(username: str) -> None:
    with _conn() as con:
        con.execute("UPDATE review_requests SET reply_unread = 0 WHERE username = ?", (username.strip().lower(),))
