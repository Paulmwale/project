"""
Model training, evaluation and forecasting logic.

Two models, per the project's Chapter 3 methodology:
  - SARIMA: classical statistical baseline, univariate (consumption only).
  - Random Forest: feature-based model using weather + facility-usage + calendar
    + lag features.

Both are evaluated on the same held-out tail of the series (time-series
train/test split, never random) using MAE, RMSE and MAPE.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from statsmodels.tsa.statespace.sarimax import SARIMAX

from .data_utils import BASE_FEATURE_COLS, TARGET_COL


def train_test_split_tail(df: pd.DataFrame, test_days: int):
    train = df.iloc[:-test_days].reset_index(drop=True)
    test = df.iloc[-test_days:].reset_index(drop=True)
    return train, test


def fit_sarima(train_series: pd.Series):
    model = SARIMAX(
        train_series,
        order=(1, 1, 1),
        seasonal_order=(1, 1, 0, 7),
        enforce_stationarity=False,
        enforce_invertibility=False,
    )
    return model.fit(disp=False)


def fit_random_forest(train_df: pd.DataFrame) -> RandomForestRegressor:
    X = train_df[BASE_FEATURE_COLS]
    y = train_df[TARGET_COL]
    model = RandomForestRegressor(
        n_estimators=300,
        max_depth=10,
        min_samples_leaf=3,
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X, y)
    return model


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mae = float(np.mean(np.abs(y_true - y_pred)))
    rmse = float(np.sqrt(np.mean((y_true - y_pred) ** 2)))
    # Avoid divide-by-zero on any zero-consumption days (possible during heavy load-shedding)
    nonzero = y_true != 0
    mape = float(np.mean(np.abs((y_true[nonzero] - y_pred[nonzero]) / y_true[nonzero])) * 100) if nonzero.any() else float("nan")
    return {"MAE": round(mae, 2), "RMSE": round(rmse, 2), "MAPE": round(mape, 2)}


def recursive_rf_forecast(rf_model: RandomForestRegressor, history_df: pd.DataFrame,
                           future_feat_df: pd.DataFrame) -> pd.DataFrame:
    """
    Random Forest has no native multi-step-ahead mode, and the feature set
    includes lag_1/lag_7/roll_mean_7, which depend on predictions made
    earlier in the horizon. This recursively predicts one day at a time,
    feeding each prediction back in as the next day's lag features.
    """
    history = history_df[["date", TARGET_COL]].copy()
    predictions = []

    for _, row in future_feat_df.iterrows():
        last_date = history["date"].max()
        lag_1 = history.loc[history["date"] == last_date, TARGET_COL].values[0]
        lag_7_date = row["date"] - pd.Timedelta(days=7)
        lag_7_match = history.loc[history["date"] == lag_7_date, TARGET_COL]
        lag_7 = lag_7_match.values[0] if len(lag_7_match) else history[TARGET_COL].tail(7).mean()
        roll_mean_7 = history[TARGET_COL].tail(7).mean()

        feat_row = row.copy()
        feat_row["lag_1"] = lag_1
        feat_row["lag_7"] = lag_7
        feat_row["roll_mean_7"] = roll_mean_7

        X = pd.DataFrame([feat_row[BASE_FEATURE_COLS].astype(float).values], columns=BASE_FEATURE_COLS)
        pred = float(rf_model.predict(X)[0])
        pred = max(pred, 0.0)

        predictions.append({"date": row["date"], "consumption_kwh_forecast": round(pred, 1)})
        history = pd.concat(
            [history, pd.DataFrame({"date": [row["date"]], TARGET_COL: [pred]})],
            ignore_index=True,
        )

    return pd.DataFrame(predictions)
