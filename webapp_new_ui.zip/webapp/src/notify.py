"""
Optional e-mail notification to the administrator when a facility review request arrives.

The in-app Admin Panel inbox always works. E-mail is an extra: it only fires if SMTP
settings are provided (Streamlit secrets or environment variables) and fails silently
otherwise — a mail problem must never block a user from submitting a request.

Settings (all required for e-mail to be sent):
    SMTP_HOST, SMTP_PORT (default 587), SMTP_USER, SMTP_PASSWORD, NOTIFY_EMAIL (admin's address)
    optional SMTP_FROM (defaults to SMTP_USER)

For Gmail use an App Password (Google Account > Security > 2-Step Verification > App passwords).
"""

import os
import smtplib
from email.message import EmailMessage


def _get(name, secrets=None):
    if secrets is not None:
        try:
            v = secrets.get(name)
            if v:
                return str(v)
        except Exception:
            pass
    return os.environ.get(name)


def email_configured(secrets=None) -> bool:
    return all(_get(k, secrets) for k in ("SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD", "NOTIFY_EMAIL"))


def send_admin_notification(subject: str, body: str, secrets=None) -> tuple[bool, str]:
    if not email_configured(secrets):
        return False, "E-mail not configured"
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = _get("SMTP_FROM", secrets) or _get("SMTP_USER", secrets)
        msg["To"] = _get("NOTIFY_EMAIL", secrets)
        msg.set_content(body)
        with smtplib.SMTP(_get("SMTP_HOST", secrets), int(_get("SMTP_PORT", secrets) or 587), timeout=10) as s:
            s.starttls()
            s.login(_get("SMTP_USER", secrets), _get("SMTP_PASSWORD", secrets))
            s.send_message(msg)
        return True, "sent"
    except Exception as exc:  # never let mail problems break the app
        return False, f"E-mail failed: {exc.__class__.__name__}"
