"""
Real Lusaka climate normals (1991-2021), used to ground the weather
simulation in actual published Zambian climate data rather than an
invented sine curve.

Source: Climate-Data.org, "Lusaka climate: Weather Lusaka & temperature
by month" (1991-2021 normals), https://en.climate-data.org/africa/zambia/
lusaka-province/lusaka-510/ (retrieved October 2026).

MEAN temperature per month = (avg. min + avg. max) / 2 from that source.
Rainfall figures are the source's monthly average totals (mm).

Humidity is NOT available from a free, reliably-scraped source for all
12 months (checked worldweatheronline.com and weather-atlas.com; only a
single October figure was available). Humidity is therefore derived from
the REAL rainfall normals above (a documented, physically-motivated proxy:
humidity tracks the rainy season), not independently sourced -- this is
disclosed wherever the dataset is described.
"""

import numpy as np
import pandas as pd

# (avg_min_c + avg_max_c) / 2, Climate-Data.org 1991-2021 normals
LUSAKA_MONTHLY_TEMP_C = {
    1: 21.55, 2: 21.45, 3: 21.20, 4: 19.95, 5: 18.60, 6: 16.75,
    7: 16.35, 8: 19.20, 9: 22.75, 10: 24.85, 11: 24.05, 12: 22.15,
}

# Average monthly rainfall total (mm), Climate-Data.org 1991-2021 normals
LUSAKA_MONTHLY_RAINFALL_MM = {
    1: 250, 2: 194, 3: 137, 4: 31, 5: 4, 6: 1,
    7: 1, 8: 0, 9: 2, 10: 16, 11: 103, 12: 231,
}

_MONTH_MIDPOINT_DOY = {
    1: 16, 2: 45, 3: 75, 4: 106, 5: 136, 6: 167,
    7: 197, 8: 228, 9: 259, 10: 289, 11: 320, 12: 350,
}


def _periodic_monthly_interp(day_of_year: np.ndarray, monthly_values: dict) -> np.ndarray:
    """Interpolates a monthly-normals dict to daily values using a periodic
    (wrap-around) linear interpolation through each month's midpoint day."""
    xs = sorted(_MONTH_MIDPOINT_DOY.values())
    ys = [monthly_values[m] for m in sorted(_MONTH_MIDPOINT_DOY, key=_MONTH_MIDPOINT_DOY.get)]
    # Extend both ends for periodic wrap-around (Dec midpoint before Jan, Jan midpoint after Dec)
    xs_ext = [xs[-1] - 365.25] + xs + [xs[0] + 365.25]
    ys_ext = [ys[-1]] + ys + [ys[0]]
    return np.interp(day_of_year, xs_ext, ys_ext)


def real_seasonal_temperature(dates: pd.DatetimeIndex, rng: np.random.Generator = None) -> np.ndarray:
    """Daily mean temperature (deg C), built from real Lusaka monthly normals
    plus realistic day-to-day variability (std ~2.0 deg C)."""
    doy = dates.dayofyear.values.astype(float)
    base = _periodic_monthly_interp(doy, LUSAKA_MONTHLY_TEMP_C)
    if rng is not None:
        base = base + rng.normal(0, 2.0, size=len(dates))
    return np.clip(base, 8, 38)


def real_seasonal_rainfall(dates: pd.DatetimeIndex, rng: np.random.Generator = None) -> np.ndarray:
    """Daily rainfall (mm), distributed from real monthly totals: rain falls
    on a subset of days per month (more often in wet months), sized so the
    expected monthly sum matches the real normal."""
    if rng is None:
        rng = np.random.default_rng(0)
    out = np.zeros(len(dates))
    months = dates.month.values
    days_in_month = dates.days_in_month.values
    for i, (m, dim) in enumerate(zip(months, days_in_month)):
        monthly_total = LUSAKA_MONTHLY_RAINFALL_MM[m]
        if monthly_total <= 0:
            continue
        p_rain = 0.45 if monthly_total > 50 else 0.15  # wet vs transitional/dry months
        if rng.random() < p_rain:
            mean_amount = monthly_total / max(dim * p_rain, 1)
            out[i] = rng.gamma(shape=1.3, scale=mean_amount / 1.3)
    return np.round(out, 1)


def real_seasonal_humidity(dates: pd.DatetimeIndex, rng: np.random.Generator = None) -> np.ndarray:
    """Daily relative humidity (%), derived from the real rainfall normals
    (humidity tracks the rainy season) since no reliable free source gives
    full monthly humidity normals for Lusaka. Documented proxy, not an
    independently-sourced figure."""
    doy = dates.dayofyear.values.astype(float)
    monthly_rain_frac = {
        m: LUSAKA_MONTHLY_RAINFALL_MM[m] / max(LUSAKA_MONTHLY_RAINFALL_MM.values())
        for m in LUSAKA_MONTHLY_RAINFALL_MM
    }
    base_frac = _periodic_monthly_interp(doy, monthly_rain_frac)
    humidity = 30 + 60 * base_frac  # 30% dry-season floor, up to ~90% in peak rain months
    if rng is not None:
        humidity = humidity + rng.normal(0, 4, size=len(dates))
    return np.clip(humidity, 15, 98)
