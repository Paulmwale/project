"""
Look-and-feel helpers for the Streamlit dashboard: navy sidebar with icon navigation, tinted KPI cards,
white panel cards, compact list rows and a consistent Plotly style.

All HTML is emitted as single-line strings (no blank lines / indentation) so Markdown never
mistakes it for a code block.
"""

import html

import streamlit as st

NAVY = "#0b2a6f"
BLUE = "#1d4ed8"
INK = "#10224a"
MUTED = "#6b7a99"
LINE = "#e3e9f5"
GREEN = "#16a34a"
AMBER = "#f59e0b"
RED = "#dc2626"

_ICONS = {
    "zap": '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    "trend": '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
    "alert": '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>'
             '<line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    "check": '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
    "money": '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
    "calendar": '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/>'
                '<line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    "users": '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>'
             '<path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    "mail": '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>'
            '<polyline points="22,6 12,13 2,6"/>',
    "bars": '<line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/>'
            '<line x1="6" y1="20" x2="6" y2="16"/>',
    "bell": '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
}


def icon(name: str, size: int = 22) -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" '
            f'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
            f'{_ICONS[name]}</svg>')


_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
:root{--navy:#0b2a6f;--blue:#1d4ed8;--bg:#f3f6fc;--ink:#10224a;--muted:#6b7a99;--line:#e3e9f5;}
html, body, .stApp, button, input, textarea, select{font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;}
.stApp{background:var(--bg);color:var(--ink);}
#MainMenu, footer, [data-testid="stToolbar"], [data-testid="stDecoration"]{visibility:hidden;height:0;}
header[data-testid="stHeader"]{background:transparent;}
.block-container{padding-top:1.2rem;padding-bottom:2rem;max-width:1320px;}

/* ---------- sidebar ---------- */
section[data-testid="stSidebar"]{background:linear-gradient(180deg,#0b2a6f 0%,#081f55 100%);border-right:0;}
section[data-testid="stSidebar"] > div{padding-top:.4rem;}
section[data-testid="stSidebar"] *{color:#dbe6ff;}
.brand{display:flex;align-items:center;gap:.7rem;padding:.9rem .4rem 1.1rem .4rem;}
.brand-logo{width:42px;height:42px;border-radius:11px;background:#fff;display:flex;align-items:center;justify-content:center;
  color:var(--navy);flex:none;}
.brand-logo svg{stroke:#0b2a6f;fill:#ffd24d;}
.brand-name{font-weight:700;font-size:1.02rem;line-height:1.15;color:#fff !important;}
.brand-sub{font-size:.72rem;opacity:.75;margin-top:2px;}
section[data-testid="stSidebar"] div[data-testid="stRadio"] label[data-testid="stWidgetLabel"]{display:none;}
section[data-testid="stSidebar"] [data-testid="stRadioGroup"]{gap:.1rem;}
section[data-testid="stSidebar"] [data-testid="stRadioGroup"] > div{width:100%;}
section[data-testid="stSidebar"] label[data-testid="stRadioOption"]{display:flex;width:100%;box-sizing:border-box;padding:.62rem .85rem;border-radius:9px;cursor:pointer;
  margin:0;transition:background .15s;}
section[data-testid="stSidebar"] label[data-testid="stRadioOption"] > div > div:first-child{display:none;}
section[data-testid="stSidebar"] label[data-testid="stRadioOption"]:hover{background:rgba(255,255,255,.09);}
section[data-testid="stSidebar"] label[data-testid="stRadioOption"][data-selected="true"]{background:#1f55d6;
  box-shadow:0 4px 14px rgba(31,85,214,.45);}
section[data-testid="stSidebar"] label[data-testid="stRadioOption"] p{font-size:.94rem;font-weight:500;margin:0;color:#c9d8ff;}
section[data-testid="stSidebar"] label[data-testid="stRadioOption"][data-selected="true"] p{color:#fff;font-weight:600;}
.side-foot{font-size:.7rem;opacity:.6;padding:1.2rem .5rem 0 .5rem;line-height:1.45;}

/* ---------- top bar ---------- */
.pg-title{font-size:1.55rem;font-weight:700;color:var(--ink);line-height:1.2;}
.pg-sub{font-size:.85rem;color:var(--muted);margin-top:2px;}
.bell{position:relative;display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;
  background:#fff;border:1px solid var(--line);color:var(--navy);}
.bell b{position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;border-radius:9px;background:#ef4444;color:#fff;
  font-size:.68rem;display:flex;align-items:center;justify-content:center;padding:0 4px;}
div[data-testid="stPopover"] > button, div[data-testid="stPopover"] button[kind]{border-radius:999px;background:#fff;
  border:1px solid var(--line);color:var(--ink);font-weight:600;padding:.25rem .9rem .25rem .35rem;}
.avatar{display:inline-flex;width:28px;height:28px;border-radius:50%;background:var(--navy);color:#fff;font-size:.72rem;
  align-items:center;justify-content:center;margin-right:.5rem;font-weight:700;}

/* ---------- cards ---------- */
[class*="st-key-card"]{background:#fff;border:1px solid var(--line);border-radius:14px;padding:1.05rem 1.25rem 1.1rem 1.25rem;
  box-shadow:0 1px 2px rgba(16,34,74,.04);}
.card-h{display:flex;justify-content:space-between;align-items:center;font-weight:700;font-size:1rem;color:var(--ink);
  margin-bottom:.55rem;}
.card-h-r{font-size:.8rem;font-weight:500;color:var(--blue);}
.card-note{font-size:.78rem;color:var(--muted);margin:.1rem 0 .4rem 0;}

/* ---------- KPI cards ---------- */
.kpi{display:flex;gap:.9rem;align-items:center;border-radius:14px;padding:1rem 1.1rem;border:1px solid;height:112px;box-sizing:border-box;margin-bottom:.9rem;}
.kpi-label{line-height:1.25;}
.kpi-ic{width:46px;height:46px;border-radius:12px;background:#fff;display:flex;align-items:center;justify-content:center;flex:none;
  box-shadow:0 1px 3px rgba(16,34,74,.08);}
.kpi-label{font-size:.82rem;color:#42557f;font-weight:500;}
.kpi-val{font-size:1.65rem;font-weight:700;color:var(--ink);line-height:1.15;}
.kpi-sub{font-size:.75rem;color:#5a6b92;margin-top:2px;}
.kpi-blue{background:#eaf1ff;border-color:#cfe0ff;} .kpi-blue .kpi-ic{color:#1d4ed8;}
.kpi-green{background:#e8f8ee;border-color:#c6ecd3;} .kpi-green .kpi-ic{color:#16a34a;}
.kpi-purple{background:#f1ecff;border-color:#ddd2fb;} .kpi-purple .kpi-ic{color:#7c3aed;}
.kpi-orange{background:#fff3df;border-color:#fbdfae;} .kpi-orange .kpi-ic{color:#ea8a0c;}
.kpi-red{background:#fdecec;border-color:#f8c9c9;} .kpi-red .kpi-ic{color:#dc2626;}

/* ---------- list rows ---------- */
.lrow{display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:.62rem 0;border-bottom:1px solid #eef2fa;}
.lrow:last-child{border-bottom:0;}
.lrow-t{font-size:.9rem;color:var(--ink);font-weight:500;}
.lrow-s{font-size:.76rem;color:var(--muted);margin-top:1px;}
.lrow-r{font-size:.82rem;color:var(--muted);text-align:right;white-space:nowrap;}
.lrow-r b{color:var(--ink);font-size:.92rem;}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:.55rem;}
.pill{display:inline-block;padding:.1rem .55rem;border-radius:999px;font-size:.72rem;font-weight:600;}
.pill-red{background:#fdecec;color:#b91c1c;} .pill-green{background:#e8f8ee;color:#15803d;}
.pill-amber{background:#fff3df;color:#b45309;}
.chip{display:inline-block;padding:.15rem .65rem;border-radius:999px;font-size:.74rem;font-weight:600;background:#fff3df;
  color:#b45309;border:1px solid #fbdfae;}

/* ---------- native widgets ---------- */
[data-testid="stMetric"]{background:#fff;border:1px solid var(--line);border-radius:12px;padding:.8rem 1rem;}
.stButton>button, .stDownloadButton>button, [data-testid="stFormSubmitButton"] button{border-radius:9px;font-weight:600;}
.stTabs [data-baseweb="tab-list"]{gap:.4rem;border-bottom:1px solid var(--line);}
.stTabs [data-baseweb="tab"]{padding:.55rem .9rem;font-weight:600;}
div[data-testid="stForm"]{background:#fff;border:1px solid var(--line);border-radius:14px;padding:1.1rem 1.25rem;}
div[data-testid="stExpander"]{background:#fff;border:1px solid var(--line);border-radius:12px;}
div[data-testid="stDataFrame"]{border:1px solid var(--line);border-radius:12px;overflow:hidden;}
div[data-testid="stAlert"]{border-radius:12px;}
h3{font-size:1.05rem !important;font-weight:700 !important;}

/* ---------- login ---------- */
.hero{text-align:center;padding:1.5rem 0 1rem 0;}
.hero .brand-logo{margin:0 auto .8rem auto;width:56px;height:56px;border-radius:15px;background:#0b2a6f;}
.hero .brand-logo svg{stroke:#fff;fill:#ffd24d;}
.hero h1{font-size:1.7rem;margin:0;color:var(--ink);}
.hero p{color:var(--muted);font-size:.9rem;margin:.35rem 0 0 0;}
</style>
"""


def inject_css():
    st.markdown(_CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Building blocks
# ---------------------------------------------------------------------------

def brand_sidebar(subtitle: str = "Mulungushi University"):
    st.sidebar.markdown(
        f'<div class="brand"><div class="brand-logo">{icon("zap", 24)}</div>'
        f'<div><div class="brand-name">Energy Forecast</div><div class="brand-sub">{html.escape(subtitle)}</div></div></div>',
        unsafe_allow_html=True)


def hero(title: str, subtitle: str):
    st.markdown(
        f'<div class="hero"><div class="brand-logo">{icon("zap", 30)}</div><h1>{html.escape(title)}</h1>'
        f'<p>{html.escape(subtitle)}</p></div>', unsafe_allow_html=True)


def card(key: str):
    """White panel. Use as `with ui.card('unique_key'):`."""
    return st.container(key=f"card_{key}")


def card_title(title: str, right: str = ""):
    st.markdown(f'<div class="card-h"><span>{title}</span><span class="card-h-r">{right}</span></div>',
                unsafe_allow_html=True)


def note(text: str):
    st.markdown(f'<div class="card-note">{text}</div>', unsafe_allow_html=True)


def kpi_html(label: str, value: str, sub: str = "", tone: str = "blue", ic: str = "zap") -> str:
    return (f'<div class="kpi kpi-{tone}"><div class="kpi-ic">{icon(ic)}</div><div>'
            f'<div class="kpi-label">{label}</div><div class="kpi-val">{value}</div>'
            f'<div class="kpi-sub">{sub}</div></div></div>')


def kpi_row(items: list[dict], widths: list[float] | None = None):
    cols = st.columns(widths or len(items))
    for col, item in zip(cols, items):
        col.markdown(kpi_html(**item), unsafe_allow_html=True)


def list_rows(rows: list[tuple]) -> str:
    """rows: (title, right_html, sub) -> HTML string."""
    out = []
    for r in rows:
        title, right = r[0], r[1]
        sub = r[2] if len(r) > 2 else ""
        out.append(f'<div class="lrow"><div><div class="lrow-t">{title}</div>'
                   + (f'<div class="lrow-s">{sub}</div>' if sub else "")
                   + f'</div><div class="lrow-r">{right}</div></div>')
    return "".join(out)


def bell(count: int) -> str:
    badge = f"<b>{count}</b>" if count else ""
    return f'<div class="bell">{icon("bell", 18)}{badge}</div>'


def avatar(name: str) -> str:
    parts = [p for p in name.replace(".", " ").split() if p]
    ini = "".join(p[0] for p in parts[:2]).upper() or "U"
    return f'<span class="avatar">{html.escape(ini)}</span>'


def style_fig(fig, height: int = 340):
    """Consistent light Plotly styling (transparent background so it sits in a card)."""
    fig.update_layout(
        height=height, margin=dict(l=6, r=6, t=10, b=6),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, system-ui, sans-serif", color=INK, size=12),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0, bgcolor="rgba(0,0,0,0)"),
        hoverlabel=dict(bgcolor="#fff", font_size=12),
    )
    fig.update_xaxes(showgrid=False, linecolor=LINE, tickcolor=LINE)
    fig.update_yaxes(gridcolor="#eef2fa", zeroline=False, linecolor="rgba(0,0,0,0)")
    return fig
