"""
Framework-independent forecasting service used by the REST API (api/main.py).

This mirrors the helpers in app.py (get_history, get_models, run_estimate) without importing
Streamlit, so the mobile app's backend and the Streamlit dashboard give identical numbers.
"""

import json
import os
from functools import lru_cache

import joblib
import numpy as np
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAXResults

from .data_utils import TARGET_COL, build_future_frame, engineer_features, load_merged
from .forecasting import recursive_rf_forecast

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(APP_DIR, "models")

FACILITY_LABELS = {"school": "School (demo facility)", "clinic": "Clinic (demo facility)"}
IS_SYNTHETIC = True   # flip to False once real facility data replaces the synthetic dataset


@lru_cache(maxsize=None)
def get_history(facility_type: str) -> pd.DataFrame:
    return engineer_features(load_merged(facility_type))


@lru_cache(maxsize=None)
def get_models(facility_type: str):
    out_dir = os.path.join(MODELS_DIR, facility_type)
    rf_model = joblib.load(os.path.join(out_dir, "rf_model.joblib"))
    sarima_model = SARIMAXResults.load(os.path.join(out_dir, "sarima_model.pkl"))
    with open(os.path.join(out_dir, "metrics.json")) as f:
        metrics = json.load(f)
    backtest = pd.read_csv(os.path.join(out_dir, "backtest.csv"), parse_dates=["date"])
    return rf_model, sarima_model, metrics, backtest


def run_estimate(facility: str, horizon: int, loadshed: bool, tariff: float, own_avg_kwh: float) -> pd.DataFrame:
    history = get_history(facility)
    rf_model = get_models(facility)[0]
    future = build_future_frame(history, facility, horizon, loadshed)
    fwd = recursive_rf_forecast(rf_model, history, future)

    scale = 1.0
    if own_avg_kwh > 0:
        baseline = history.loc[history["loadshedding_flag"] == 0, TARGET_COL].mean()
        scale = own_avg_kwh / baseline if baseline else 1.0
    fwd["consumption_kwh_forecast"] = (fwd["consumption_kwh_forecast"] * scale).round(1)
    fwd["estimated_cost_zmw"] = (fwd["consumption_kwh_forecast"] * tariff).round(2)
    return fwd


def monitoring(facility: str, threshold_pct: float, days: int = 30) -> dict:
    """Recent deviation of actual consumption from the Random Forest forecast, with alert flags."""
    backtest = get_models(facility)[3].copy()
    backtest["deviation_pct"] = np.where(
        backtest["actual"] != 0,
        (backtest["actual"] - backtest["rf_pred"]).abs() / backtest["actual"] * 100,
        0,
    )
    backtest["alert"] = backtest["deviation_pct"] > threshold_pct
    recent = backtest.tail(days)
    rows = [
        {"date": r.date.strftime("%Y-%m-%d"), "actual": round(float(r.actual), 1),
         "forecast": round(float(r.rf_pred), 1), "deviation_pct": round(float(r.deviation_pct), 1),
         "alert": bool(r.alert)}
        for r in recent.itertuples()
    ]
    return {"facility": facility, "threshold_pct": threshold_pct, "days": len(rows),
            "alert_count": int(recent["alert"].sum()), "rows": rows}


def model_summary(facility: str, days: int = 90) -> dict:
    """Accuracy metrics (MAE/RMSE/MAPE for SARIMA and Random Forest) plus the backtest series."""
    _, _, metrics, backtest = get_models(facility)
    tail = backtest.tail(days)
    series = [
        {"date": r.date.strftime("%Y-%m-%d"), "actual": round(float(r.actual), 1),
         "sarima": round(float(r.sarima_pred), 1), "random_forest": round(float(r.rf_pred), 1),
         "loadshedding": bool(r.loadshedding_flag)}
        for r in tail.itertuples()
    ]
    return {"facility": facility, "metrics": metrics, "series": series}
