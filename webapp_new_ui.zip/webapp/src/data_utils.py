"""
Data loading and feature engineering for the forecasting dashboard.

Works against the merged_dataset.csv produced either by the synthetic data
generator (data/*_merged_dataset.csv) or, once available, real facility data
exported in the same column layout. Swapping synthetic -> real data requires
no code changes here as long as the column names match.
"""

import os
import numpy as np
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

FACILITY_FILES = {
    "school": os.path.join(DATA_DIR, "school_merged_dataset.csv"),
    "clinic": os.path.join(DATA_DIR, "clinic_merged_dataset.csv"),
}

# Feature columns used by the Random Forest model. Common across facility
# types so the modeling code doesn't need per-facility branching.
BASE_FEATURE_COLS = [
    "temperature_c", "humidity_pct", "rainfall_mm",
    "occupancy_rate", "operating_hours", "is_weekend",
    "loadshedding_flag",
    "doy_sin", "doy_cos", "dow_sin", "dow_cos",
    "lag_1", "lag_7", "roll_mean_7",
]
TARGET_COL = "consumption_kwh"


def load_merged(facility_type: str) -> pd.DataFrame:
    path = FACILITY_FILES[facility_type]
    df = pd.read_csv(path, parse_dates=["date"])
    df = df.sort_values("date").reset_index(drop=True)
    return df


def _cyclical(values: np.ndarray, period: int):
    sin = np.sin(2 * np.pi * values / period)
    cos = np.cos(2 * np.pi * values / period)
    return sin, cos


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Adds calendar, lag and rolling features. Assumes df is sorted by date
    and has no gaps (daily frequency)."""
    out = df.copy()
    out["doy_sin"], out["doy_cos"] = _cyclical(out["date"].dt.dayofyear.values, 365.25)
    out["dow_sin"], out["dow_cos"] = _cyclical(out["date"].dt.dayofweek.values, 7)

    out["lag_1"] = out[TARGET_COL].shift(1)
    out["lag_7"] = out[TARGET_COL].shift(7)
    out["roll_mean_7"] = out[TARGET_COL].shift(1).rolling(window=7, min_periods=1).mean()

    # Drop the first few rows where lag features are NaN (can't be used for training)
    out = out.dropna(subset=["lag_1", "lag_7", "roll_mean_7"]).reset_index(drop=True)
    return out


def school_term_flag(dates: pd.DatetimeIndex) -> np.ndarray:
    """Same Zambian 3-term calendar logic as the synthetic generator, reused
    here so forward-looking (future) feature generation stays consistent
    with how the historical data was built."""
    in_session = np.ones(len(dates), dtype=int)
    for i, d in enumerate(dates):
        md = (d.month, d.day)
        if (md >= (12, 10)) or (md <= (1, 14)):
            in_session[i] = 0
        elif (4, 15) <= md <= (5, 4):
            in_session[i] = 0
        elif (8, 5) <= md <= (8, 25):
            in_session[i] = 0
    return in_session


# Real Lusaka climate normals (see zambia_climate.py for source/citation).
from .zambia_climate import real_seasonal_temperature, real_seasonal_rainfall, real_seasonal_humidity


def seasonal_temperature(dates: pd.DatetimeIndex) -> np.ndarray:
    return real_seasonal_temperature(dates, rng=None)  # no noise: smoothed normal for forward planning


def seasonal_humidity(dates: pd.DatetimeIndex) -> np.ndarray:
    return real_seasonal_humidity(dates, rng=None)


def seasonal_rainfall(dates: pd.DatetimeIndex) -> np.ndarray:
    return real_seasonal_rainfall(dates, rng=np.random.default_rng(0))


def build_future_frame(history: pd.DataFrame, facility_type: str, horizon_days: int,
                        assume_loadshedding: bool) -> pd.DataFrame:
    """
    Builds a feature frame for `horizon_days` beyond the last date in `history`,
    WITHOUT a known target (consumption_kwh is unknown -- that's what we're
    forecasting). Weather and usage are synthesized using the same seasonal /
    calendar assumptions as the historical data, which is the same approach
    the project's Chapter 3 methodology describes for forward planning. Once
    a real weather-forecast API is wired in, replace seasonal_temperature/
    seasonal_humidity/seasonal_rainfall with live forecast values for a
    real deployment.
    """
    last_date = history["date"].max()
    future_dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=horizon_days, freq="D")

    temperature_c = seasonal_temperature(future_dates)
    humidity_pct = seasonal_humidity(future_dates)
    rainfall_mm = seasonal_rainfall(future_dates)
    is_weekend = (future_dates.dayofweek >= 5).astype(int)

    if facility_type == "school":
        in_session = school_term_flag(future_dates)
        operating = in_session * (1 - is_weekend)
        occupancy_rate = np.where(operating == 1, 0.85, 0.08)
        operating_hours = np.where(operating == 1, 9.0, 1.0)
    else:  # clinic
        occupancy_rate = np.where(is_weekend == 0, 0.75, 0.35)
        operating_hours = np.where(is_weekend == 0, 10.0, 6.0)

    loadshedding_flag = np.full(len(future_dates), 1 if assume_loadshedding else 0)

    future = pd.DataFrame({
        "date": future_dates,
        "temperature_c": temperature_c,
        "humidity_pct": humidity_pct,
        "rainfall_mm": rainfall_mm,
        "occupancy_rate": occupancy_rate,
        "operating_hours": operating_hours,
        "is_weekend": is_weekend,
        "loadshedding_flag": loadshedding_flag,
    })
    future["doy_sin"], future["doy_cos"] = _cyclical(future["date"].dt.dayofyear.values, 365.25)
    future["dow_sin"], future["dow_cos"] = _cyclical(future["date"].dt.dayofweek.values, 7)
    return future
