"""
Bill-style PDF report for a cost estimate.

Deliberately labelled "ESTIMATE" throughout and carries no utility branding, so it
can't be mistaken for an actual ZESCO invoice.
"""

import io
from datetime import datetime, timezone
from xml.sax.saxutils import escape

import pandas as pd
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (HRFlowable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

NAVY = colors.HexColor("#1e3a8a")
BLUE = colors.HexColor("#2563eb")
LIGHT = colors.HexColor("#eff6ff")
GREY = colors.HexColor("#6b7280")
AMBER_BG = colors.HexColor("#fef3c7")

FACILITY_LABELS = {"school": "School (demo facility profile)", "clinic": "Clinic (demo facility profile)"}


def _styles():
    ss = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t", parent=ss["Title"], fontName="Helvetica-Bold", fontSize=20,
                                textColor=colors.white, alignment=0, leading=24),
        "sub": ParagraphStyle("s", parent=ss["Normal"], fontSize=9, textColor=colors.HexColor("#dbeafe")),
        "h": ParagraphStyle("h", parent=ss["Heading3"], fontName="Helvetica-Bold", fontSize=11, textColor=NAVY,
                            spaceBefore=8, spaceAfter=4),
        "body": ParagraphStyle("b", parent=ss["Normal"], fontSize=9, leading=12),
        "small": ParagraphStyle("sm", parent=ss["Normal"], fontSize=7.5, leading=10, textColor=GREY),
        "label": ParagraphStyle("l", parent=ss["Normal"], fontSize=8, textColor=GREY),
        "value": ParagraphStyle("v", parent=ss["Normal"], fontSize=10, fontName="Helvetica-Bold"),
        "big": ParagraphStyle("bg", parent=ss["Normal"], fontSize=22, fontName="Helvetica-Bold",
                              textColor=NAVY, leading=26),
        "warn": ParagraphStyle("w", parent=ss["Normal"], fontSize=8.5, leading=11,
                               textColor=colors.HexColor("#78350f")),
    }


def _kv(label, value, st):
    return [Paragraph(label, st["label"]), Paragraph(escape(str(value)), st["value"])]


def build_bill_pdf(user: dict, estimate: dict, forecast: pd.DataFrame, reference: str,
                   is_synthetic: bool = True) -> bytes:
    """
    user      : {'full_name','organisation','username'}
    estimate  : {'facility','horizon','loadshed','tariff','own_avg'}
    forecast  : DataFrame with date, consumption_kwh_forecast, estimated_cost_zmw
    """
    st = _styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm,
                            topMargin=14 * mm, bottomMargin=16 * mm,
                            title=f"Electricity cost estimate {reference}", author="Demand Forecasting Prototype")
    W = A4[0] - 32 * mm
    story = []

    # ---- Header band ----
    header = Table(
        [[Paragraph("ELECTRICITY COST ESTIMATE", st["title"]),
          Paragraph(f"Ref: <b>{escape(reference)}</b><br/>Issued: {datetime.now(timezone.utc):%d %b %Y}", st["sub"])],
         [Paragraph("AI-based demand forecast · Community Facilities, Zambia", st["sub"]), ""]],
        colWidths=[W * 0.68, W * 0.32])
    header.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), NAVY), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 10), ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, 0), 10), ("BOTTOMPADDING", (0, -1), (-1, -1), 10),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
    ]))
    story += [header, Spacer(1, 8)]

    # ---- Account / estimate details ----
    start, end = forecast["date"].min(), forecast["date"].max()
    left = Table([
        _kv("PREPARED FOR", user["full_name"], st),
        _kv("ORGANISATION", user.get("organisation") or "—", st),
        _kv("ACCOUNT", f"@{user['username']}", st),
    ], colWidths=[28 * mm, W / 2 - 28 * mm])
    right = Table([
        _kv("FACILITY PROFILE", FACILITY_LABELS.get(estimate["facility"], estimate["facility"]), st),
        _kv("PERIOD", f"{start:%d %b %Y} – {end:%d %b %Y} ({estimate['horizon']} days)", st),
        _kv("LOAD-SHEDDING", "Assumed to continue" if estimate["loadshed"] else "Not assumed", st),
    ], colWidths=[32 * mm, W / 2 - 32 * mm])
    for t in (left, right):
        t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                               ("TOPPADDING", (0, 0), (-1, -1), 1)]))
    story += [Table([[left, right]], colWidths=[W / 2, W / 2]), Spacer(1, 6)]

    # ---- Totals box ----
    total_kwh = forecast["consumption_kwh_forecast"].sum()
    total_cost = forecast["estimated_cost_zmw"].sum()
    avg_kwh = forecast["consumption_kwh_forecast"].mean()
    peak_kwh = forecast["consumption_kwh_forecast"].max()
    peak_day = forecast.loc[forecast["consumption_kwh_forecast"].idxmax(), "date"]

    box = Table([
        [Paragraph("ESTIMATED ENERGY CHARGE", st["label"]), Paragraph("PROJECTED ENERGY", st["label"]),
         Paragraph("AVERAGE / DAY", st["label"]), Paragraph("PEAK DAY", st["label"])],
        [Paragraph(f"ZMW {total_cost:,.2f}", st["big"]), Paragraph(f"<b>{total_kwh:,.0f}</b> kWh", st["value"]),
         Paragraph(f"<b>{avg_kwh:,.0f}</b> kWh", st["value"]),
         Paragraph(f"<b>{peak_kwh:,.0f}</b> kWh<br/><font size=7 color='#6b7280'>{peak_day:%d %b}</font>", st["value"])],
    ], colWidths=[W * 0.40, W * 0.22, W * 0.19, W * 0.19])
    box.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("BOX", (0, 0), (-1, -1), 0.8, BLUE),
        ("LEFTPADDING", (0, 0), (-1, -1), 10), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, 0), 8), ("BOTTOMPADDING", (0, -1), (-1, -1), 8),
    ]))
    story += [box, Spacer(1, 8)]

    # ---- Calculation basis ----
    story.append(Paragraph("How this estimate was calculated", st["h"]))
    basis = (f"Daily demand was forecast with a Random Forest model trained on historical consumption, "
             f"weather and facility-usage data. Cost = forecast kWh × tariff of <b>ZMW {estimate['tariff']:.2f} per kWh</b>.")
    if estimate.get("own_avg", 0) > 0:
        basis += f" The forecast was scaled to your stated average usage of <b>{estimate['own_avg']:,.0f} kWh/day</b>."
    story.append(Paragraph(basis, st["body"]))

    # ---- Chart ----
    n = len(forecast)
    d = Drawing(W, 120)
    bc = VerticalBarChart()
    bc.x, bc.y, bc.width, bc.height = 38, 22, W - 50, 88
    bc.data = [list(forecast["estimated_cost_zmw"].round(2))]
    bc.bars[0].fillColor = BLUE
    bc.barSpacing = 1 if n > 14 else 3
    bc.categoryAxis.categoryNames = [f"{x:%d}" if n > 14 else f"{x:%d %b}" for x in forecast["date"]]
    bc.categoryAxis.labels.fontSize = 6 if n > 14 else 7
    bc.categoryAxis.labels.angle = 0
    bc.valueAxis.labels.fontSize = 7
    bc.valueAxis.valueMin = 0
    bc.valueAxis.labelTextFormat = "%0.0f"
    d.add(bc)
    story += [Paragraph("Estimated daily cost (ZMW)", st["h"]), d]

    # ---- Daily table ----
    rows = [["Date", "Day", "Forecast (kWh)", "Tariff (ZMW/kWh)", "Cost (ZMW)"]]
    for _, r in forecast.iterrows():
        rows.append([f"{r['date']:%d %b %Y}", f"{r['date']:%a}", f"{r['consumption_kwh_forecast']:,.1f}",
                     f"{estimate['tariff']:.2f}", f"{r['estimated_cost_zmw']:,.2f}"])
    rows.append(["TOTAL", "", f"{total_kwh:,.1f}", "", f"{total_cost:,.2f}"])
    tbl = Table(rows, colWidths=[W * 0.26, W * 0.12, W * 0.22, W * 0.22, W * 0.18], repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, colors.HexColor("#f8fafc")]),
        ("BACKGROUND", (0, -1), (-1, -1), LIGHT), ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("LINEABOVE", (0, -1), (-1, -1), 0.8, NAVY),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story += [Paragraph("Daily breakdown", st["h"]), tbl, Spacer(1, 8)]

    # ---- Notices ----
    notes = ["<b>This is an ESTIMATE, not an invoice.</b> It is not issued by ZESCO or any utility and cannot be "
             "used to pay or dispute a bill.",
             "Covers energy charges only (tariff × kWh). Fixed/service charges, taxes, levies and generator fuel "
             "are <b>not</b> included."]
    if is_synthetic:
        notes.append("<b>Prototype data notice:</b> consumption and facility-usage data are SYNTHETIC; weather is "
                     "grounded in Lusaka climate normals (1991–2021). Figures will be re-validated once real "
                     "facility data is obtained.")
    if estimate["loadshed"]:
        notes.append("Load-shedding scenario: demand is lower on affected days because supply is interrupted.")
    warn = Table([[Paragraph("<br/>".join(f"• {n_}" for n_ in notes), st["warn"])]], colWidths=[W])
    warn.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), AMBER_BG), ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#f59e0b")),
                              ("LEFTPADDING", (0, 0), (-1, -1), 8), ("TOPPADDING", (0, 0), (-1, -1), 6),
                              ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    story.append(warn)

    def _footer(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(GREY)
        canvas.drawString(16 * mm, 9 * mm, "AI-Based Electricity Demand Forecasting for Community Facilities — "
                                           "Mulungushi University, ICT431 Capstone Prototype")
        canvas.drawRightString(A4[0] - 16 * mm, 9 * mm, f"{reference} · Page {doc_.page}")
        canvas.restoreState()

    doc.build(story, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()
