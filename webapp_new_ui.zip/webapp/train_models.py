"""
Offline training script. Run this once (and again whenever the underlying
data changes -- e.g. after swapping in real facility data) to produce the
model artifacts the Streamlit app loads.

    python train_models.py

Writes, per facility type, into models/<facility_type>/:
    rf_model.joblib        -- trained Random Forest
    sarima_model.pkl       -- trained SARIMA results (statsmodels)
    metrics.json           -- MAE/RMSE/MAPE for both models on the test window
    backtest.csv           -- date, actual, sarima_pred, rf_pred for the test window
    feature_cols.json      -- the exact feature column order the RF model expects
"""

import json
import os

import joblib
import numpy as np
import pandas as pd

from src.data_utils import load_merged, engineer_features, BASE_FEATURE_COLS, TARGET_COL
from src.forecasting import (
    train_test_split_tail, fit_sarima, fit_random_forest, compute_metrics,
)

TEST_DAYS = 90
MODELS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")


def train_for_facility(facility_type: str):
    print(f"\n=== Training models for facility_type='{facility_type}' ===")
    raw = load_merged(facility_type)
    df = engineer_features(raw)

    train, test = train_test_split_tail(df, TEST_DAYS)
    print(f"Train: {len(train)} days | Test: {len(test)} days")

    # ---- SARIMA (univariate baseline) ----
    train_series = train.set_index("date")[TARGET_COL]
    sarima_results = fit_sarima(train_series)
    sarima_forecast = sarima_results.get_forecast(steps=len(test))
    sarima_pred = sarima_forecast.predicted_mean.values
    sarima_pred = np.clip(sarima_pred, 0, None)

    # ---- Random Forest (feature-based) ----
    rf_model = fit_random_forest(train)
    X_test = test[BASE_FEATURE_COLS]
    rf_pred = np.clip(rf_model.predict(X_test), 0, None)

    y_test = test[TARGET_COL].values
    sarima_metrics = compute_metrics(y_test, sarima_pred)
    rf_metrics = compute_metrics(y_test, rf_pred)
    print(f"SARIMA  -> {sarima_metrics}")
    print(f"RF      -> {rf_metrics}")

    # ---- Refit on FULL data for forward forecasting (used by the dashboard's planning panel) ----
    full_series = df.set_index("date")[TARGET_COL]
    sarima_full = fit_sarima(full_series)
    rf_full = fit_random_forest(df)

    # ---- Save artifacts ----
    out_dir = os.path.join(MODELS_DIR, facility_type)
    os.makedirs(out_dir, exist_ok=True)

    joblib.dump(rf_full, os.path.join(out_dir, "rf_model.joblib"))
    sarima_full.save(os.path.join(out_dir, "sarima_model.pkl"))

    with open(os.path.join(out_dir, "feature_cols.json"), "w") as f:
        json.dump(BASE_FEATURE_COLS, f)

    with open(os.path.join(out_dir, "metrics.json"), "w") as f:
        json.dump({"SARIMA": sarima_metrics, "RandomForest": rf_metrics, "test_days": TEST_DAYS}, f, indent=2)

    backtest = pd.DataFrame({
        "date": test["date"].values,
        "actual": y_test,
        "sarima_pred": np.round(sarima_pred, 1),
        "rf_pred": np.round(rf_pred, 1),
        "loadshedding_flag": test["loadshedding_flag"].values,
    })
    backtest.to_csv(os.path.join(out_dir, "backtest.csv"), index=False)

    print(f"Artifacts written to: {out_dir}")


if __name__ == "__main__":
    for facility in ["school", "clinic"]:
        train_for_facility(facility)
    print("\nDone.")
