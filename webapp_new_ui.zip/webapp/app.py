"""
AI-Based Electricity Demand Forecasting Dashboard — prototype
Mulungushi University | ICT431 Capstone Project | Paul Mwale

Access control
  * Everyone must log in (or register as a standard user).
  * USERS    -> Cost Estimator (enter their own inputs, get a forecast cost) + My History.
  * ADMINS   -> everything above, the full forecasting dashboard
                (Forecast & Model Comparison, Monitoring & Alerts, Planning & Reports)
                and the Admin Panel (users, activity log, all estimates, settings).
"""

import json
import os

import joblib
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from statsmodels.tsa.statespace.sarimax import SARIMAXResults

from src import auth, notify, report, ui
from src.data_utils import load_merged, engineer_features, build_future_frame, TARGET_COL
from src.forecasting import recursive_rf_forecast

APP_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(APP_DIR, "models")

FACILITY_LABELS = {"school": "School (demo facility)", "clinic": "Clinic (demo facility)"}

st.set_page_config(
    page_title="Electricity Demand Forecasting — Prototype",
    page_icon="⚡",
    layout="wide",
)
ui.inject_css()

# Data source transparency flag — flip to False once real facility data is substituted.
is_synthetic = True


# ---------------------------------------------------------------------------
# Data / model loading (cached)
# ---------------------------------------------------------------------------

@st.cache_data(show_spinner=False)
def get_history(facility_type: str) -> pd.DataFrame:
    raw = load_merged(facility_type)
    return engineer_features(raw)


@st.cache_resource(show_spinner=True)
def get_models(facility_type: str):
    out_dir = os.path.join(MODELS_DIR, facility_type)
    rf_model = joblib.load(os.path.join(out_dir, "rf_model.joblib"))
    sarima_model = SARIMAXResults.load(os.path.join(out_dir, "sarima_model.pkl"))
    with open(os.path.join(out_dir, "metrics.json")) as f:
        metrics = json.load(f)
    backtest = pd.read_csv(os.path.join(out_dir, "backtest.csv"), parse_dates=["date"])
    return rf_model, sarima_model, metrics, backtest


def data_banner(facility_type: str | None = None, history: pd.DataFrame | None = None):
    if is_synthetic:
        with st.expander("⚠️ Consumption data is SYNTHETIC · weather uses real Lusaka climate normals (details)"):
            st.markdown(
                "**Consumption & facility-usage data: SYNTHETIC** — standing in for real facility data while "
                "ZESCO/facility data requests are pending (see project report, Chapter 3). "
                "**Weather data: grounded in real Lusaka climate normals** (Climate-Data.org, 1991–2021) rather than "
                "an invented curve — see the dataset README for the exact source and method. "
                "Figures shown reflect this dataset and will be re-validated once real facility consumption data "
                "is obtained.")
    elif history is not None:
        st.info(f"**Data source:** {facility_type.title()} facility — historical records, "
                f"{history['date'].min().date()} to {history['date'].max().date()}")


# ---------------------------------------------------------------------------
# Authentication UI
# ---------------------------------------------------------------------------

def _admin_seed():
    """Bootstrap admin credentials from Streamlit secrets or environment, if provided."""
    user = pw = None
    try:
        user = st.secrets.get("ADMIN_USERNAME")
        pw = st.secrets.get("ADMIN_PASSWORD")
    except Exception:
        pass
    user = user or os.environ.get("ADMIN_USERNAME")
    pw = pw or os.environ.get("ADMIN_PASSWORD")
    return (user, pw) if user and pw else (None, None)


def render_login():
    _, mid, _ = st.columns([1, 1.4, 1])
    with mid:
        ui.hero("Electricity Demand Forecasting",
                "AI-based demand forecasting and cost estimation for community facilities in Zambia.")

        allow_reg = auth.get_setting("allow_registration") == "1"
        tab_names = ["🔑 Log in"] + (["📝 Register"] if allow_reg else [])
        tabs = st.tabs(tab_names)

        with tabs[0]:
            with st.form("login_form"):
                username = st.text_input("Username")
                password = st.text_input("Password", type="password")
                submitted = st.form_submit_button("Log in", type="primary", width="stretch")
            if submitted:
                user, msg = auth.authenticate(username, password)
                if user:
                    st.session_state["user"] = user
                    st.session_state.pop("estimate", None)
                    st.rerun()
                else:
                    st.error(msg)

        if allow_reg:
            with tabs[1]:
                with st.form("register_form"):
                    full_name = st.text_input("Full name")
                    organisation = st.text_input("Organisation / facility (optional)")
                    new_username = st.text_input("Choose a username",
                                                 help="3–30 characters: letters, numbers, . - _")
                    new_pw = st.text_input("Choose a password", type="password",
                                           help="At least 8 characters, mixing letters with numbers or symbols.")
                    new_pw2 = st.text_input("Confirm password", type="password")
                    reg = st.form_submit_button("Create account", width="stretch")
                if reg:
                    if new_pw != new_pw2:
                        st.error("Passwords don't match.")
                    else:
                        ok, msg = auth.create_user(new_username, new_pw, full_name, role="user",
                                                   organisation=organisation)
                        if ok:
                            auth.log_activity(new_username.strip().lower(), "register", "self-registered")
                            st.success(msg + " You can now log in.")
                        else:
                            st.error(msg)

        st.caption("Prototype for the ICT431 Capstone Project, Mulungushi University.")


def render_forced_password_change(user: dict):
    _, mid, _ = st.columns([1, 1.4, 1])
    with mid:
        st.title("🔐 Choose a new password")
        st.warning("This account is using a temporary or default password. "
                   "Set a new one before continuing.")
        with st.form("force_pw_form"):
            pw1 = st.text_input("New password", type="password")
            pw2 = st.text_input("Confirm new password", type="password")
            go_ = st.form_submit_button("Save password", type="primary", width="stretch")
        if go_:
            if pw1 != pw2:
                st.error("Passwords don't match.")
            else:
                ok, msg = auth.change_password(user["username"], pw1)
                if ok:
                    auth.log_activity(user["username"], "password_changed", "forced change")
                    st.session_state["user"]["must_change"] = False
                    st.rerun()
                else:
                    st.error(msg)
        if st.button("Log out"):
            st.session_state["user"] = None
            st.rerun()


def account_menu(user: dict):
    """Top-right user menu: role, change password, log out."""
    with st.popover(user["full_name"] or user["username"], icon=":material/account_circle:"):
        st.caption(f"@{user['username']} · {'Administrator' if user['role'] == 'admin' else 'User'}")
        st.markdown("**Change password**")
        with st.form("change_pw_form", clear_on_submit=True):
            cur = st.text_input("Current password", type="password")
            new1 = st.text_input("New password", type="password")
            new2 = st.text_input("Confirm new password", type="password")
            ok_btn = st.form_submit_button("Update password")
        if ok_btn:
            if not auth.verify_password(user["username"], cur):
                st.error("Current password is incorrect.")
            elif new1 != new2:
                st.error("New passwords don't match.")
            else:
                ok, msg = auth.change_password(user["username"], new1)
                (st.success if ok else st.error)(msg)
                if ok:
                    auth.log_activity(user["username"], "password_changed", "self-service")
        if st.button("Log out", width="stretch", type="primary"):
            auth.log_activity(user["username"], "logout")
            st.session_state["user"] = None
            st.session_state.pop("estimate", None)
            st.rerun()


def sticky(widget, label, store, default, **kw):
    """A widget whose value survives switching pages (Streamlit drops state of widgets that aren't rendered)."""
    wk = f"w_{store}"
    if store not in st.session_state:
        st.session_state[store] = default
    if wk not in st.session_state:
        st.session_state[wk] = st.session_state[store]
    val = widget(label, key=wk, **kw)
    st.session_state[store] = val
    return val


def render_topbar(user: dict, title: str, subtitle: str = "", facility: bool = False, notif: int = 0):
    """Page title on the left; optional facility picker, notification bell and user menu on the right."""
    widths = [5, 2.3, 0.55, 1.9] if facility else [7, 0.55, 2.0]
    cols = st.columns(widths, vertical_alignment="center")
    with cols[0]:
        st.markdown(f'<div class="pg-title">{title}</div><div class="pg-sub">{subtitle}</div>', unsafe_allow_html=True)
    chosen = None
    i = 1
    if facility:
        with cols[1]:
            chosen = sticky(st.selectbox, "Facility", "facility", "school", options=list(FACILITY_LABELS),
                            format_func=FACILITY_LABELS.get, label_visibility="collapsed")
        i = 2
    with cols[i]:
        st.markdown(ui.bell(notif), unsafe_allow_html=True)
    with cols[i + 1]:
        account_menu(user)
    return chosen


# ---------------------------------------------------------------------------
# Cost estimator (all users)
# ---------------------------------------------------------------------------

def run_estimate(facility: str, horizon: int, loadshed: bool, tariff: float, own_avg_kwh: float) -> pd.DataFrame:
    history = get_history(facility)
    rf_model = get_models(facility)[0]
    future = build_future_frame(history, facility, horizon, loadshed)
    fwd = recursive_rf_forecast(rf_model, history, future)

    scale = 1.0
    if own_avg_kwh > 0:
        baseline = history.loc[history["loadshedding_flag"] == 0, TARGET_COL].mean()
        scale = own_avg_kwh / baseline if baseline else 1.0
    fwd["consumption_kwh_forecast"] = (fwd["consumption_kwh_forecast"] * scale).round(1)
    fwd["estimated_cost_zmw"] = (fwd["consumption_kwh_forecast"] * tariff).round(2)
    return fwd


def view_estimator(user: dict):
    st.caption("Enter your own details below. The AI model forecasts demand for the period you choose and "
               "converts it into an estimated electricity bill.")
    data_banner()

    default_tariff = float(auth.get_setting("default_tariff") or 2.5)

    with st.form("estimator_form"):
        c1, c2 = st.columns(2)
        with c1:
            facility = st.selectbox("Facility type", list(FACILITY_LABELS), format_func=FACILITY_LABELS.get,
                                    help="Which demo facility profile your facility most resembles.")
            horizon = st.slider("Forecast period (days)", 1, 30, 7)
            loadshed = st.checkbox("Assume load-shedding continues during this period", value=False)
        with c2:
            tariff = st.number_input("Electricity tariff (ZMW per kWh)", min_value=0.1, max_value=20.0,
                                     value=default_tariff, step=0.05,
                                     help="Default set by the administrator. Replace with your ERB-approved tariff "
                                          "band from your ZESCO bill.")
            own_avg = st.number_input("Your facility's average daily usage (kWh/day) — optional", min_value=0.0,
                                      max_value=100000.0, value=0.0, step=10.0,
                                      help="Find this on your ZESCO bill (monthly kWh ÷ days). If entered, the "
                                           "forecast is scaled to your facility's size. Leave at 0 to use the "
                                           "demo facility's size.")
        run = st.form_submit_button("Calculate cost", type="primary")

    if run:
        fwd = run_estimate(facility, horizon, loadshed, tariff, own_avg)
        res = {
            "facility": facility, "horizon": horizon, "loadshed": loadshed, "tariff": tariff,
            "own_avg": own_avg, "forecast": fwd,
        }
        est_id = auth.save_estimate(user["username"], facility, horizon, loadshed, tariff, own_avg,
                                    fwd["consumption_kwh_forecast"].sum(), fwd["consumption_kwh_forecast"].max(),
                                    fwd["estimated_cost_zmw"].sum())
        res["id"] = est_id
        res["ref"] = f"EST-{est_id:05d}"
        st.session_state["estimate"] = res
        auth.log_activity(user["username"], "estimate",
                          f"{facility}, {horizon}d, tariff {tariff}, loadshed={loadshed}")

    res = st.session_state.get("estimate")
    if not res:
        st.info("Fill in the form and press **Calculate cost** to see your estimate.")
        return

    fwd = res["forecast"]
    total_kwh = fwd["consumption_kwh_forecast"].sum()
    total_cost = fwd["estimated_cost_zmw"].sum()
    st.markdown(f"#### Result — next {res['horizon']} day(s), {FACILITY_LABELS[res['facility']]}")
    ui.kpi_row([
        dict(label="Estimated total cost", value=f"ZMW {total_cost:,.0f}", sub=f"at ZMW {res['tariff']:.2f} per kWh",
             tone="green", ic="money"),
        dict(label="Projected energy", value=f"{total_kwh:,.0f} kWh", sub=f"next {res['horizon']} day(s)",
             tone="blue", ic="zap"),
        dict(label="Average per day", value=f"{fwd['consumption_kwh_forecast'].mean():,.0f} kWh", sub="daily mean",
             tone="purple", ic="trend"),
        dict(label="Peak day", value=f"{fwd['consumption_kwh_forecast'].max():,.0f} kWh", sub="highest single day",
             tone="orange", ic="bars"),
    ])

    with ui.card("est_chart"):
        ui.card_title("Estimated daily cost", "ZMW per day")
        fig = go.Figure()
        fig.add_trace(go.Bar(x=fwd["date"], y=fwd["estimated_cost_zmw"], name="Daily cost (ZMW)",
                             marker_color="#2563eb", marker_cornerradius=6))
        ui.style_fig(fig, 320)
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

    if res["loadshed"]:
        st.info("Load-shedding scenario: consumption on affected days is lower because supply is interrupted, "
                "but if you run a generator the fuel cost is **not** included in this estimate.")
    if res["own_avg"] > 0:
        st.caption(f"Forecast scaled to your stated average of {res['own_avg']:,.0f} kWh/day.")
    st.caption("Estimates cover energy charges only (tariff × kWh). Fixed/service charges, taxes and levies on your "
               "bill are not included.")

    show = fwd.rename(columns={"consumption_kwh_forecast": "forecast_kwh"})
    st.dataframe(show, width="stretch", hide_index=True)

    d1, d2 = st.columns(2)
    pdf_bytes = report.build_bill_pdf(
        user, {"facility": res["facility"], "horizon": res["horizon"], "loadshed": res["loadshed"],
               "tariff": res["tariff"], "own_avg": res["own_avg"]},
        fwd, reference=res["ref"], is_synthetic=is_synthetic)
    d1.download_button("📄 Download PDF report", data=pdf_bytes, file_name=f"{res['ref']}_cost_estimate.pdf",
                       mime="application/pdf", type="primary", key="dl_pdf_main")
    d2.download_button("⬇ Download data (CSV)", data=show.to_csv(index=False).encode("utf-8"),
                       file_name=f"cost_estimate_{pd.Timestamp.today().date()}.csv", mime="text/csv")


def view_my_history(user: dict):
    rows = auth.get_estimates(user["username"])
    if not rows:
        st.info("You haven't calculated any estimates yet.")
        return
    df = pd.DataFrame(rows)[["id", "ts", "facility", "horizon_days", "loadshedding", "tariff", "own_avg_kwh",
                             "total_kwh", "peak_kwh", "total_cost"]]
    df["id"] = df["id"].map(lambda i: f"EST-{i:05d}")
    df["loadshedding"] = df["loadshedding"].map({0: "No", 1: "Yes"})
    df.columns = ["Ref", "Time (UTC)", "Facility", "Days", "Load-shedding", "Tariff (ZMW/kWh)",
                  "Own avg (kWh/day)", "Total kWh", "Peak kWh", "Total cost (ZMW)"]
    st.dataframe(df, width="stretch", hide_index=True)

    st.markdown("**Download a PDF report for a past estimate**")
    by_ref = {f"EST-{r['id']:05d}": r for r in rows}
    pick = st.selectbox("Estimate", list(by_ref),
                        format_func=lambda k: f"{k} — {by_ref[k]['horizon_days']} days, ZMW {by_ref[k]['total_cost']:,.0f}"
                                              f" ({by_ref[k]['ts'][:10]})")
    r = by_ref[pick]
    fwd = run_estimate(r["facility"], r["horizon_days"], bool(r["loadshedding"]), r["tariff"], r["own_avg_kwh"])
    pdf_bytes = report.build_bill_pdf(
        user, {"facility": r["facility"], "horizon": r["horizon_days"], "loadshed": bool(r["loadshedding"]),
               "tariff": r["tariff"], "own_avg": r["own_avg_kwh"]},
        fwd, reference=pick, is_synthetic=is_synthetic)
    st.download_button("📄 Download PDF", data=pdf_bytes, file_name=f"{pick}_cost_estimate.pdf",
                       mime="application/pdf", key="dl_pdf_hist")


# ---------------------------------------------------------------------------
# Facility review requests (user side)
# ---------------------------------------------------------------------------

STATUS_LABEL = {"new": "🟡 New", "in_progress": "🔵 In progress", "resolved": "🟢 Resolved"}


def view_review_request(user: dict):
    st.caption("Want a closer look at your facility's electricity use? Send a request and the administrator will "
               "get back to you. Replies appear below on this page.")

    my_est = auth.get_estimates(user["username"], limit=50)
    est_options = {0: "— none —"}
    est_options.update({e["id"]: f"EST-{e['id']:05d} — {e['horizon_days']} days, ZMW {e['total_cost']:,.0f}"
                        for e in my_est})

    with st.form("review_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        with c1:
            fac_name = st.text_input("Facility name", value=user.get("organisation") or "")
            fac_type = st.selectbox("Facility type", ["school", "clinic", "other"],
                                    format_func=lambda x: {"school": "School", "clinic": "Clinic / health centre",
                                                           "other": "Other community facility"}[x])
            location = st.text_input("Town / location (optional)")
        with c2:
            contact = st.text_input("Best contact (phone or e-mail)")
            subject = st.text_input("Subject", max_chars=150,
                                    placeholder="e.g. High bills during the hot season")
            est_pick = st.selectbox("Attach one of my estimates (optional)", list(est_options),
                                    format_func=est_options.get)
        message = st.text_area("What would you like reviewed?", max_chars=3000, height=130,
                               placeholder="Describe your concern: unusual bills, load-shedding impact, "
                                           "planning for solar or a generator, etc.")
        sent = st.form_submit_button("Send request", type="primary")

    if sent:
        ok, result = auth.create_review_request(user["username"], fac_name, fac_type, location, contact, subject,
                                                message, est_pick or None)
        if ok:
            auth.log_activity(user["username"], "review_request", f"#{result}: {subject.strip()[:80]}")
            mail_ok, _ = notify.send_admin_notification(
                f"[Review request #{result}] {subject.strip()}",
                f"New facility review request #{result}\n\nFrom: {user['full_name']} (@{user['username']})\n"
                f"Facility: {fac_name} ({fac_type}) {location}\nContact: {contact}\n\n{message}\n",
                secrets=st.secrets if hasattr(st, "secrets") else None)
            st.success(f"Request #{result} sent to the administrator." +
                       (" They've also been notified by e-mail." if mail_ok else ""))
        else:
            st.error(result)

    st.markdown("---")
    st.markdown("#### My requests")
    reqs = auth.list_review_requests(user["username"])
    unread = sum(1 for r in reqs if r["reply_unread"])
    if unread:
        st.info(f"🔔 You have {unread} new repl{'y' if unread == 1 else 'ies'} from the administrator.")
        if st.button("Mark all replies as read"):
            auth.mark_replies_read(user["username"])
            st.rerun()
    if not reqs:
        st.caption("You haven't sent any requests yet.")
    for r in reqs:
        flag = " 🔔 NEW REPLY" if r["reply_unread"] else ""
        with st.expander(f"#{r['id']} · {r['subject']} · {STATUS_LABEL[r['status']]}{flag}", expanded=bool(r["reply_unread"])):
            st.caption(f"Sent {r['ts']} UTC · {r['facility_name']}")
            st.write(r["message"])
            if r["estimate_id"]:
                st.caption(f"Attached estimate: EST-{r['estimate_id']:05d}")
            if r["admin_reply"]:
                st.markdown(f"**Administrator reply** ({r['replied_at']} UTC):")
                st.success(r["admin_reply"])
            else:
                st.caption("No reply yet.")


# ---------------------------------------------------------------------------
# Admin dashboard tabs (unchanged analytics from the original prototype)
# ---------------------------------------------------------------------------

@st.cache_data(show_spinner=False)
def forward_forecast(facility_type: str, horizon: int, loadshed: bool) -> pd.DataFrame:
    history = get_history(facility_type)
    rf_model = get_models(facility_type)[0]
    future = build_future_frame(history, facility_type, horizon, loadshed)
    return recursive_rf_forecast(rf_model, history, future)


def deviation_frame(backtest: pd.DataFrame, thr: float) -> pd.DataFrame:
    m = backtest.copy()
    m["deviation_pct"] = np.where(m["actual"] != 0, (m["actual"] - m["rf_pred"]).abs() / m["actual"] * 100, 0)
    m["alert"] = m["deviation_pct"] > thr
    return m


def default_tariff() -> float:
    return float(auth.get_setting("default_tariff") or 2.5)


def page_dashboard(history, backtest, metrics, facility_type):
    thr = st.session_state.get("thr", 15)
    tariff = st.session_state.get("tariff", default_tariff())
    fwd = forward_forecast(facility_type, 7, False)
    recent = deviation_frame(backtest, thr).tail(30)
    n_alerts = int(recent["alert"].sum())
    rf_m, sa_m = metrics["RandomForest"], metrics["SARIMA"]
    gain = round((sa_m["MAPE"] - rf_m["MAPE"]) / sa_m["MAPE"] * 100, 1) if sa_m["MAPE"] else 0
    kwh = fwd["consumption_kwh_forecast"]

    data_banner(facility_type, history)
    ui.kpi_row([
        dict(label="Demand · next 7 days", value=f"{kwh.sum():,.0f} kWh", sub=f"avg {kwh.mean():,.0f} kWh per day",
             tone="blue", ic="zap"),
        dict(label="Estimated cost", value=f"ZMW {kwh.sum() * tariff:,.0f}", sub=f"at ZMW {tariff:.2f} per kWh",
             tone="green", ic="money"),
        dict(label="Model error (MAPE)", value=f"{rf_m['MAPE']}%", sub=f"{gain}% better than SARIMA",
             tone="purple", ic="check"),
        dict(label="Alerts · last 30 days", value=str(n_alerts), sub=f"deviation above {thr}%",
             tone="red" if n_alerts else "orange", ic="alert"),
    ])

    left, right = st.columns([1.45, 1])
    with left:
        with ui.card("dash_demand"):
            ui.card_title("Demand overview", "Actual vs forecast · last 30 days")
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=recent["date"], y=recent["actual"], name="Actual", mode="lines+markers",
                                     line=dict(color="#2563eb", width=2.5, shape="spline"), marker=dict(size=5),
                                     fill="tozeroy", fillcolor="rgba(37,99,235,0.08)"))
            fig.add_trace(go.Scatter(x=recent["date"], y=recent["rf_pred"], name="Forecast (Random Forest)",
                                     line=dict(color="#10224a", width=1.8, dash="dot")))
            hits = recent[recent["alert"]]
            fig.add_trace(go.Scatter(x=hits["date"], y=hits["actual"], mode="markers", name="Alert",
                                     marker=dict(color="#dc2626", size=10, symbol="x")))
            ui.style_fig(fig, 300)
            fig.update_yaxes(title="kWh per day")
            st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})
    with right:
        with ui.card("dash_alerts"):
            ui.card_title("Recent alerts", f"threshold {thr}%")
            hits = recent[recent["alert"]].sort_values("date", ascending=False).head(5)
            if hits.empty:
                st.markdown(ui.list_rows([("No days above the threshold", '<span class="pill pill-green">All clear</span>',
                                           "Forecast is tracking actual demand closely")]), unsafe_allow_html=True)
            else:
                rows = []
                for _, r in hits.iterrows():
                    over = r["actual"] > r["rf_pred"]
                    rows.append((f"Actual {r['actual']:,.0f} vs forecast {r['rf_pred']:,.0f} kWh",
                                 f'<span class="pill pill-red">{r["deviation_pct"]:.0f}% {"over" if over else "under"}</span>'
                                 f'<br>{r["date"]:%d %b %Y}'))
                st.markdown(ui.list_rows(rows), unsafe_allow_html=True)

    left, right = st.columns([1.45, 1])
    with left:
        with ui.card("dash_accuracy"):
            ui.card_title("Forecast accuracy", "last 30 days")
            dev = recent["deviation_pct"]
            parts = [("Within 5%", int((dev <= 5).sum()), "#16a34a"),
                     (f"5% to {thr}%", int(((dev > 5) & (dev <= thr)).sum()), "#f59e0b"),
                     (f"Above {thr}% (alert)", n_alerts, "#dc2626")]
            c1, c2 = st.columns([1, 1], vertical_alignment="center")
            with c1:
                pie = go.Figure(go.Pie(labels=[p[0] for p in parts], values=[p[1] for p in parts], hole=0.72, sort=False,
                                       marker=dict(colors=[p[2] for p in parts], line=dict(color="#fff", width=2)),
                                       textinfo="none", hovertemplate="%{label}: %{value} days<extra></extra>"))
                pie.update_layout(height=230, margin=dict(l=0, r=0, t=0, b=0), showlegend=False,
                                  paper_bgcolor="rgba(0,0,0,0)",
                                  annotations=[dict(text=f"<b>{len(recent)}</b><br>days", showarrow=False,
                                                    font=dict(size=20, color=ui.INK))])
                st.plotly_chart(pie, width="stretch", config={"displayModeBar": False})
            with c2:
                st.markdown("".join(
                    f'<div class="lrow"><div><span class="dot" style="background:{c}"></span>{lbl}</div>'
                    f'<div class="lrow-r"><b>{n}</b> days</div></div>' for lbl, n, c in parts), unsafe_allow_html=True)
    with right:
        with ui.card("dash_upcoming"):
            ui.card_title("Upcoming forecast", "next 5 days")
            rows = [(f"{d:%a, %d %b %Y}", f"<b>{k:,.0f} kWh</b><br>ZMW {k * tariff:,.0f}")
                    for d, k in zip(fwd["date"].head(5), kwh.head(5))]
            st.markdown(ui.list_rows(rows), unsafe_allow_html=True)


def tab_forecast(history, backtest, metrics):
    sarima_m, rf_m = metrics["SARIMA"], metrics["RandomForest"]

    def pct_improvement(base, new):
        return round((base - new) / base * 100, 1) if base else 0

    ui.kpi_row([
        dict(label="MAE (kWh)", value=f"{rf_m['MAE']}", sub=f"{pct_improvement(sarima_m['MAE'], rf_m['MAE'])}% better than SARIMA",
             tone="blue", ic="bars"),
        dict(label="RMSE (kWh)", value=f"{rf_m['RMSE']}", sub=f"{pct_improvement(sarima_m['RMSE'], rf_m['RMSE'])}% better than SARIMA",
             tone="purple", ic="trend"),
        dict(label="MAPE (%)", value=f"{rf_m['MAPE']}", sub=f"{pct_improvement(sarima_m['MAPE'], rf_m['MAPE'])}% better than SARIMA",
             tone="green", ic="check"),
    ])

    with ui.card("fc_backtest"):
        ui.card_title("Backtest: forecast vs. actual consumption")
        ui.note(f"Both models were trained on {len(history) - len(backtest)} days of history and evaluated on the "
                f"held-out final {len(backtest)} days (never seen during training), a proper time-series "
                f"out-of-sample test, not a random split.")
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=backtest["date"], y=backtest["actual"], name="Actual",
                                 line=dict(color="#10224a", width=2)))
        fig.add_trace(go.Scatter(x=backtest["date"], y=backtest["sarima_pred"], name="SARIMA (baseline)",
                                 line=dict(color="#f59e0b", width=1.5, dash="dot")))
        fig.add_trace(go.Scatter(x=backtest["date"], y=backtest["rf_pred"], name="Random Forest (ML)",
                                 line=dict(color="#2563eb", width=1.8)))
        loadshed_days = backtest[backtest["loadshedding_flag"] == 1]
        fig.add_trace(go.Scatter(x=loadshed_days["date"], y=loadshed_days["actual"], mode="markers",
                                 name="Load-shedding day", marker=dict(color="#dc2626", size=6)))
        ui.style_fig(fig, 420)
        fig.update_yaxes(title="Consumption (kWh/day)")
        st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

    with ui.card("fc_table"):
        ui.card_title("Model accuracy comparison")
        st.dataframe(pd.DataFrame({"SARIMA (baseline)": sarima_m, "Random Forest (ML)": rf_m}).T, width="stretch")
        ui.note("The Random Forest model outperforms the SARIMA baseline mainly because it has access to temperature, "
                "occupancy and load-shedding features that SARIMA, a purely univariate time-series model, cannot see. "
                "This matches the gap identified in the project's literature review (Chapter 2).")


def tab_monitoring(backtest):
    with ui.card("mon_controls"):
        thr = sticky(st.slider, "Alert threshold: flag a day when |actual − forecast| exceeds this % of actual",
                     "thr", 15, min_value=5, max_value=50)
    monitor = deviation_frame(backtest, thr)
    recent = monitor.tail(30)
    n_alerts = int(recent["alert"].sum())

    ui.kpi_row([
        dict(label="Alert days · last 30", value=str(n_alerts), sub="no active alerts" if n_alerts == 0 else "needs attention",
             tone="red" if n_alerts else "green", ic="alert" if n_alerts else "check"),
        dict(label="Average deviation", value=f"{recent['deviation_pct'].mean():.1f}%", sub="|actual − forecast| / actual",
             tone="blue", ic="trend"),
        dict(label="Worst day", value=f"{recent['deviation_pct'].max():.1f}%", sub="largest single deviation",
             tone="orange", ic="bars"),
    ])

    with ui.card("mon_chart"):
        ui.card_title("Recent forecast deviation", "last 30 days")
        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(x=recent["date"], y=recent["actual"], name="Actual",
                                  line=dict(color="#10224a", width=2)))
        fig2.add_trace(go.Scatter(x=recent["date"], y=recent["rf_pred"], name="Forecast (RF)",
                                  line=dict(color="#2563eb", width=2, dash="dash")))
        alert_days = recent[recent["alert"]]
        fig2.add_trace(go.Scatter(x=alert_days["date"], y=alert_days["actual"], mode="markers",
                                  name=f"Alert (>{thr}% deviation)",
                                  marker=dict(color="#dc2626", size=10, symbol="x")))
        ui.style_fig(fig2, 380)
        fig2.update_yaxes(title="Consumption (kWh/day)")
        st.plotly_chart(fig2, width="stretch", config={"displayModeBar": False})

    with ui.card("mon_log"):
        ui.card_title("Alert log")
        log = recent[["date", "actual", "rf_pred", "deviation_pct", "alert"]].rename(
            columns={"rf_pred": "forecast", "deviation_pct": "deviation (%)"})
        log["deviation (%)"] = log["deviation (%)"].round(1)
        st.dataframe(log.sort_values("date", ascending=False), width="stretch", hide_index=True)


def tab_planning(history, facility_type):
    with ui.card("plan_controls"):
        ui.card_title("Planning scenario")
        c1, c2, c3 = st.columns(3, vertical_alignment="bottom")
        with c1:
            horizon_days = sticky(st.select_slider, "Forecast horizon (days)", "horizon", 7, options=[7, 14, 30])
        with c2:
            tariff_rate = sticky(st.number_input, "Tariff (ZMW per kWh)", "tariff", default_tariff(),
                                 min_value=0.1, max_value=20.0, step=0.05,
                                 help="Indicative only. Replace with the facility's actual ERB-approved tariff band.")
        with c3:
            assume_loadshedding = sticky(st.toggle, "Assume continued load-shedding", "loadshed", False,
                                         help="Scenario switch: see how the forecast changes if load-shedding continues.")

    forward = forward_forecast(facility_type, horizon_days, assume_loadshedding)
    total_kwh = forward["consumption_kwh_forecast"].sum()
    avg_kwh = forward["consumption_kwh_forecast"].mean()
    peak_kwh = forward["consumption_kwh_forecast"].max()
    est_cost = total_kwh * tariff_rate

    ui.kpi_row([
        dict(label=f"Projected total ({horizon_days}d)", value=f"{total_kwh:,.0f} kWh", sub="forecast energy", tone="blue", ic="zap"),
        dict(label="Avg daily demand", value=f"{avg_kwh:,.0f} kWh", sub="per day", tone="purple", ic="trend"),
        dict(label="Peak daily demand", value=f"{peak_kwh:,.0f} kWh", sub="highest day", tone="orange", ic="bars"),
        dict(label="Estimated cost", value=f"ZMW {est_cost:,.0f}", sub=f"at ZMW {tariff_rate:.2f} per kWh", tone="green", ic="money"),
    ])

    with ui.card("plan_chart"):
        ui.card_title(f"Forward planning forecast: next {horizon_days} days")
        ui.note("Beyond the historical data, future weather and facility-usage inputs are synthesized from the same "
                "seasonal/calendar assumptions used to build the training data (see project report, Chapter 3). "
                "Once a live weather-forecast feed is connected, this panel uses real forecast inputs instead.")
        fig3 = go.Figure()
        tail_hist = history.tail(21)
        fig3.add_trace(go.Scatter(x=tail_hist["date"], y=tail_hist[TARGET_COL], name="Recent actual",
                                  line=dict(color="#10224a", width=2)))
        fig3.add_trace(go.Scatter(x=forward["date"], y=forward["consumption_kwh_forecast"],
                                  name="Forward forecast", line=dict(color="#16a34a", width=2.2, dash="dash")))
        ui.style_fig(fig3, 360)
        fig3.update_yaxes(title="Consumption (kWh/day)")
        st.plotly_chart(fig3, width="stretch", config={"displayModeBar": False})

    if assume_loadshedding:
        st.info("Scenario: continued load-shedding assumed over this horizon. Consider sizing backup generation "
                f"(generator or solar+battery) to cover at least the peak daily demand of **{peak_kwh:,.0f} kWh** "
                "on affected days.")

    with ui.card("plan_report"):
        ui.card_title("Downloadable planning report")
        rep_df = forward.copy()
        rep_df["estimated_cost_zmw"] = (rep_df["consumption_kwh_forecast"] * tariff_rate).round(2)
        st.download_button("⬇ Download forecast + cost report (CSV)", data=rep_df.to_csv(index=False).encode("utf-8"),
                           file_name=f"{facility_type}_planning_report_{pd.Timestamp.today().date()}.csv",
                           mime="text/csv")
        st.dataframe(rep_df, width="stretch", hide_index=True)


# ---------------------------------------------------------------------------
# Admin: review-request inbox
# ---------------------------------------------------------------------------

def view_admin_inbox(admin: dict):
    reqs = auth.list_review_requests()
    if not reqs:
        st.info("No review requests yet. When a user submits one it will appear here.")
        return

    counts = {s: sum(1 for r in reqs if r["status"] == s) for s in auth.REQUEST_STATUSES}
    ui.kpi_row([
        dict(label="New", value=str(counts["new"]), sub="awaiting a reply", tone="orange", ic="mail"),
        dict(label="In progress", value=str(counts["in_progress"]), sub="being looked into", tone="blue", ic="trend"),
        dict(label="Resolved", value=str(counts["resolved"]), sub="closed", tone="green", ic="check"),
    ])
    flt = st.radio("Show", ["all", *auth.REQUEST_STATUSES], horizontal=True,
                   format_func=lambda x: "All" if x == "all" else STATUS_LABEL[x])
    shown = [r for r in reqs if flt == "all" or r["status"] == flt]
    if not shown:
        st.caption("Nothing in this view.")
    est_by_id = {e["id"]: e for e in auth.get_estimates(limit=5000)}

    for r in shown:
        with st.expander(f"#{r['id']} · {r['subject']} · {r['facility_name']} (@{r['username']}) · "
                         f"{STATUS_LABEL[r['status']]}", expanded=(r["status"] == "new")):
            st.caption(f"Received {r['ts']} UTC · {r['facility_type']} · {r['location'] or 'location not given'}")
            st.markdown(f"**Contact:** {r['contact']}")
            st.write(r["message"])
            e = est_by_id.get(r["estimate_id"]) if r["estimate_id"] else None
            if e:
                st.info(f"Attached estimate EST-{e['id']:05d}: {e['horizon_days']} days, {e['total_kwh']:,.0f} kWh, "
                        f"ZMW {e['total_cost']:,.0f} at ZMW {e['tariff']:.2f}/kWh")
            with st.form(f"reply_form_{r['id']}"):
                status = st.selectbox("Status", auth.REQUEST_STATUSES, index=auth.REQUEST_STATUSES.index(r["status"]),
                                      format_func=STATUS_LABEL.get, key=f"st_{r['id']}")
                reply = st.text_area("Reply to user (visible in their account)", value=r["admin_reply"],
                                     key=f"rp_{r['id']}", height=100)
                if st.form_submit_button("Save"):
                    ok, msg = auth.update_review_request(r["id"], status, reply, admin["username"])
                    if ok:
                        auth.log_activity(admin["username"], "admin_review_update", f"#{r['id']} -> {status}")
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)


# ---------------------------------------------------------------------------
# Admin panel
# ---------------------------------------------------------------------------

def view_admin(admin: dict):

    users = auth.list_users()
    estimates = auth.get_estimates()
    ui.kpi_row([
        dict(label="Accounts", value=str(len(users)), sub="registered", tone="blue", ic="users"),
        dict(label="Active users", value=str(sum(1 for u in users if u["active"])), sub="can log in", tone="green", ic="check"),
        dict(label="Estimates run", value=str(len(estimates)), sub="all time", tone="purple", ic="bars"),
        dict(label="Total estimated cost", value=f"ZMW {sum(e['total_cost'] for e in estimates):,.0f}",
             sub="across all estimates", tone="orange", ic="money"),
    ])

    t_users, t_est, t_log, t_set = st.tabs(["👥 Users", "🧮 All estimates", "📜 Activity log", "⚙️ Settings"])

    # ---- Users ----
    with t_users:
        udf = pd.DataFrame(users)[["username", "full_name", "organisation", "role", "active", "last_login",
                                   "created_at"]]
        st.dataframe(udf, width="stretch", hide_index=True)

        left, right = st.columns(2)
        with left:
            st.markdown("**Create account**")
            with st.form("admin_create_user", clear_on_submit=True):
                n_user = st.text_input("Username")
                n_name = st.text_input("Full name")
                n_org = st.text_input("Organisation (optional)")
                n_role = st.selectbox("Role", ["user", "admin"])
                n_pw = st.text_input("Temporary password", type="password",
                                     help="The person will be forced to choose a new password at first login.")
                create = st.form_submit_button("Create account")
            if create:
                ok, msg = auth.create_user(n_user, n_pw, n_name, role=n_role, organisation=n_org, must_change=True)
                if ok:
                    auth.log_activity(admin["username"], "admin_create_user", f"{n_user.strip().lower()} ({n_role})")
                    st.success(msg)
                    st.rerun()
                else:
                    st.error(msg)

        with right:
            st.markdown("**Manage account**")
            target = st.selectbox("Select account", [u["username"] for u in users], key="admin_target")
            t = auth.get_user(target)
            if t:
                st.caption(f"{t['full_name']} · {t['role']} · {'active' if t['active'] else 'DEACTIVATED'}")
                b1, b2 = st.columns(2)
                if t["active"]:
                    if b1.button("Deactivate", width="stretch"):
                        ok, msg = auth.set_active(target, False)
                        if ok:
                            auth.log_activity(admin["username"], "admin_deactivate", target)
                        (st.success if ok else st.error)(msg)
                        if ok:
                            st.rerun()
                else:
                    if b1.button("Activate", width="stretch"):
                        ok, msg = auth.set_active(target, True)
                        if ok:
                            auth.log_activity(admin["username"], "admin_activate", target)
                        (st.success if ok else st.error)(msg)
                        if ok:
                            st.rerun()
                new_role = "user" if t["role"] == "admin" else "admin"
                if b2.button(f"Make {new_role}", width="stretch"):
                    ok, msg = auth.set_role(target, new_role)
                    if ok:
                        auth.log_activity(admin["username"], "admin_set_role", f"{target} -> {new_role}")
                    (st.success if ok else st.error)(msg)
                    if ok:
                        st.rerun()

                with st.form("admin_reset_pw", clear_on_submit=True):
                    tmp = st.text_input("Temporary password", type="password")
                    reset = st.form_submit_button("Reset password")
                if reset:
                    ok, msg = auth.change_password(target, tmp, must_change=True)
                    if ok:
                        auth.log_activity(admin["username"], "admin_reset_password", target)
                        msg = f"Password reset for '{target}'. They must change it at next login."
                    (st.success if ok else st.error)(msg)

                if t["role"] != "admin":
                    with st.expander("Danger zone"):
                        confirm = st.checkbox(f"I understand this permanently deletes '{target}'", key="del_confirm")
                        if st.button("Delete account", disabled=not confirm):
                            ok, msg = auth.delete_user(target)
                            if ok:
                                auth.log_activity(admin["username"], "admin_delete_user", target)
                            (st.success if ok else st.error)(msg)
                            if ok:
                                st.rerun()

    # ---- Estimates ----
    with t_est:
        if not estimates:
            st.info("No estimates have been calculated yet.")
        else:
            edf = pd.DataFrame(estimates)
            edf["loadshedding"] = edf["loadshedding"].map({0: "No", 1: "Yes"})
            st.dataframe(edf, width="stretch", hide_index=True)
            st.download_button("⬇ Export all estimates (CSV)", data=edf.to_csv(index=False).encode("utf-8"),
                               file_name=f"all_estimates_{pd.Timestamp.today().date()}.csv", mime="text/csv")

    # ---- Activity ----
    with t_log:
        act = auth.get_activity(500)
        if act:
            st.dataframe(pd.DataFrame(act), width="stretch", hide_index=True)
        else:
            st.info("No activity recorded yet.")

    # ---- Settings ----
    with t_set:
        with st.form("admin_settings"):
            tariff_default = st.number_input(
                "Default tariff shown to users (ZMW per kWh)", min_value=0.1, max_value=20.0,
                value=float(auth.get_setting("default_tariff") or 2.5), step=0.05,
                help="Set this to the current ERB-approved tariff band you want users to start from.")
            allow_reg = st.checkbox("Allow visitors to self-register",
                                    value=auth.get_setting("allow_registration") == "1")
            saved = st.form_submit_button("Save settings")
        if saved:
            auth.set_setting("default_tariff", f"{tariff_default:.2f}")
            auth.set_setting("allow_registration", "1" if allow_reg else "0")
            auth.log_activity(admin["username"], "admin_settings",
                              f"default_tariff={tariff_default:.2f}, allow_registration={int(allow_reg)}")
            st.success("Settings saved.")


# ---------------------------------------------------------------------------
# Main routing
# ---------------------------------------------------------------------------

auth.init_db(*_admin_seed())
if "user" not in st.session_state:
    st.session_state["user"] = None

user = st.session_state["user"]

if user is None:
    render_login()
    st.stop()

if user.get("must_change"):
    render_forced_password_change(user)
    st.stop()

is_admin = user["role"] == "admin"
ui.brand_sidebar()

if is_admin:
    n_new = auth.count_open_requests()
    PAGES = {
        "dashboard": (":material/dashboard: Dashboard", "Dashboard",
                      "Demand forecast, accuracy and alerts at a glance"),
        "forecast": (":material/query_stats: Forecast & Models", "Forecast & Model Comparison",
                     "Backtest of the SARIMA baseline against the Random Forest model"),
        "monitor": (":material/notifications_active: Monitoring & Alerts", "Monitoring & Alerts",
                    "Compare forecast with actual demand and flag large deviations"),
        "planning": (":material/event_note: Planning & Reports", "Planning & Reports",
                     "Forward forecast, load-shedding scenarios and downloadable reports"),
        "estimator": (":material/payments: Cost Estimator", "Cost Estimator",
                      "Forecast demand for a period and convert it into an estimated bill"),
        "inbox": (":material/inbox: Review Requests" + (f" ({n_new})" if n_new else ""), "Review Requests",
                  "Facility review requests from users"),
        "admin": (":material/admin_panel_settings: Admin Panel", "Admin Panel",
                  "Users, estimates, activity log and settings"),
    }
    notif = n_new
else:
    unread = auth.count_unread_replies(user["username"])
    PAGES = {
        "estimator": (":material/payments: Cost Estimator", "Electricity Cost Estimator",
                      "Forecast your facility's demand and estimate the bill"),
        "history": (":material/history: My History", "My History", "Your past estimates and PDF reports"),
        "review": (":material/mail: Request a Review" + (f" ({unread})" if unread else ""), "Request a Facility Review",
                   "Ask the administrator for a closer look at your electricity use"),
    }
    notif = unread

page = st.sidebar.radio("Navigate", list(PAGES), format_func=lambda k: PAGES[k][0], key="nav",
                        label_visibility="collapsed")
st.sidebar.markdown('<div class="side-foot">ICT431 Capstone Project<br>Mulungushi University<br>'
                    'Dept. of Computer Science and IT</div>', unsafe_allow_html=True)

needs_facility = is_admin and page in ("dashboard", "forecast", "monitor", "planning")
facility_type = render_topbar(user, PAGES[page][1], PAGES[page][2], facility=needs_facility, notif=notif)

if needs_facility:
    history = get_history(facility_type)
    rf_model, sarima_model, metrics, backtest = get_models(facility_type)

if page == "dashboard":
    page_dashboard(history, backtest, metrics, facility_type)
elif page == "forecast":
    data_banner(facility_type, history)
    tab_forecast(history, backtest, metrics)
elif page == "monitor":
    data_banner(facility_type, history)
    tab_monitoring(backtest)
elif page == "planning":
    data_banner(facility_type, history)
    tab_planning(history, facility_type)
elif page == "estimator":
    view_estimator(user)
elif page == "history":
    view_my_history(user)
elif page == "review":
    view_review_request(user)
elif page == "inbox":
    view_admin_inbox(user)
else:
    view_admin(user)


# ---------------------------------------------------------------------------
# Footer
# ---------------------------------------------------------------------------

st.caption(
    "AI-Based Electricity Demand Forecasting for Community Facilities — prototype dashboard. "
    "Built with Python, statsmodels (SARIMA), scikit-learn (Random Forest) and Streamlit. "
    "Mulungushi University, Department of Computer Science and IT, ICT431 Capstone Project."
)
