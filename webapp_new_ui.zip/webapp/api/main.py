"""
REST API for the mobile app (and any future client).

Wraps the same login, forecasting, cost-estimate, PDF and review-request code that the Streamlit
dashboard uses (src/auth.py, src/service.py, src/report.py), so both front ends share one database
and give identical numbers.

Run (from the webapp/ folder):
    uvicorn api.main:app --host 0.0.0.0 --port 8000
Interactive docs: http://localhost:8000/docs
"""

import os
import secrets
import time
from typing import Literal, Optional

import jwt
from fastapi import Depends, FastAPI, HTTPException, Query, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field

from src import auth, notify, report, service

TOKEN_TTL_SECONDS = 12 * 3600
_env_secret = os.environ.get("API_SECRET")
if not _env_secret:
    print("WARNING: API_SECRET is not set - using a random key; logins will not survive a server restart. "
          "Set API_SECRET to a long random string for anything beyond local testing.")
SECRET = _env_secret or secrets.token_hex(32)

app = FastAPI(title="Electricity Demand Forecasting API", version="1.0",
              description="Backend for the ICT431 capstone prototype (mobile + web).")
bearer = HTTPBearer(auto_error=False)

Facility = Literal["school", "clinic"]


@app.on_event("startup")
def _startup():
    auth.init_db(os.environ.get("ADMIN_USERNAME"), os.environ.get("ADMIN_PASSWORD"))


# --------------------------------------------------------------------------- auth helpers

def _make_token(user: dict) -> str:
    now = int(time.time())
    return jwt.encode({"sub": user["username"], "iat": now, "exp": now + TOKEN_TTL_SECONDS}, SECRET, algorithm="HS256")


def current_user(creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer)) -> dict:
    """Valid token + active account. Allows accounts that still must change their password."""
    if creds is None:
        raise HTTPException(401, "Not logged in.")
    try:
        payload = jwt.decode(creds.credentials, SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(401, "Session expired. Please log in again.")
    user = auth.get_user(payload["sub"])
    if user is None or not user["active"]:
        raise HTTPException(401, "Account not available.")
    return user


def active_user(user: dict = Depends(current_user)) -> dict:
    if user["must_change"]:
        raise HTTPException(403, "password_change_required")
    return user


def admin_user(user: dict = Depends(active_user)) -> dict:
    if user["role"] != "admin":
        raise HTTPException(403, "Administrator access required.")
    return user


def _check(result):
    """auth.* helpers return (ok, message); turn failures into HTTP 400."""
    ok, msg = result
    if not ok:
        raise HTTPException(400, msg)
    return msg


# --------------------------------------------------------------------------- schemas

class LoginIn(BaseModel):
    username: str
    password: str


class RegisterIn(BaseModel):
    username: str
    password: str
    full_name: str
    organisation: str = ""


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str


class EstimateIn(BaseModel):
    facility: Facility = "school"
    horizon_days: int = Field(7, ge=1, le=30)
    loadshedding: bool = False
    tariff: float = Field(2.5, ge=0.1, le=20)
    own_avg_kwh: float = Field(0, ge=0, le=100000)


class ReviewRequestIn(BaseModel):
    facility_name: str
    facility_type: str = ""
    location: str = ""
    contact: str
    subject: str
    message: str
    estimate_id: Optional[int] = None


class ReplyIn(BaseModel):
    status: Literal["new", "in_progress", "resolved"]
    reply: str = ""


class NewUserIn(BaseModel):
    username: str
    full_name: str
    organisation: str = ""
    role: Literal["user", "admin"] = "user"
    temporary_password: str


class UserPatchIn(BaseModel):
    active: Optional[bool] = None
    role: Optional[Literal["user", "admin"]] = None


class ResetPasswordIn(BaseModel):
    temporary_password: str


class SettingsIn(BaseModel):
    default_tariff: Optional[float] = Field(None, ge=0.1, le=20)
    allow_registration: Optional[bool] = None


def _estimate_payload(est_id: int, ref: str, req: EstimateIn, fwd) -> dict:
    rows = [{"date": r.date.strftime("%Y-%m-%d"), "kwh": float(r.consumption_kwh_forecast),
             "cost_zmw": float(r.estimated_cost_zmw)} for r in fwd.itertuples()]
    return {
        "id": est_id, "ref": ref, "facility": req.facility, "horizon_days": req.horizon_days,
        "loadshedding": req.loadshedding, "tariff": req.tariff, "own_avg_kwh": req.own_avg_kwh,
        "total_kwh": round(float(fwd["consumption_kwh_forecast"].sum()), 1),
        "avg_kwh": round(float(fwd["consumption_kwh_forecast"].mean()), 1),
        "peak_kwh": round(float(fwd["consumption_kwh_forecast"].max()), 1),
        "total_cost_zmw": round(float(fwd["estimated_cost_zmw"].sum()), 2),
        "is_synthetic": service.IS_SYNTHETIC, "rows": rows,
    }


def _ref(i: int) -> str:
    return f"EST-{i:05d}"


# --------------------------------------------------------------------------- public

@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/meta")
def meta():
    return {"facilities": [{"id": k, "label": v} for k, v in service.FACILITY_LABELS.items()],
            "default_tariff": float(auth.get_setting("default_tariff") or 2.5),
            "allow_registration": auth.get_setting("allow_registration") == "1",
            "is_synthetic": service.IS_SYNTHETIC}


@app.post("/auth/login")
def login(body: LoginIn):
    user, msg = auth.authenticate(body.username, body.password)
    if user is None:
        raise HTTPException(401, msg)
    return {"token": _make_token(user), "user": user}


@app.post("/auth/register", status_code=201)
def register(body: RegisterIn):
    if auth.get_setting("allow_registration") != "1":
        raise HTTPException(403, "Registration is currently closed. Ask an administrator for an account.")
    msg = _check(auth.create_user(body.username, body.password, body.full_name, role="user",
                                  organisation=body.organisation))
    auth.log_activity(body.username.strip().lower(), "register", "self-registered (mobile/API)")
    return {"message": msg}


# --------------------------------------------------------------------------- signed-in users

@app.get("/me")
def me(user: dict = Depends(current_user)):
    return {"user": user, "unread_replies": auth.count_unread_replies(user["username"])}


@app.post("/auth/change-password")
def change_password(body: ChangePasswordIn, user: dict = Depends(current_user)):
    if not auth.verify_password(user["username"], body.current_password):
        raise HTTPException(400, "Current password is incorrect.")
    msg = _check(auth.change_password(user["username"], body.new_password))
    auth.log_activity(user["username"], "password_changed", "via API")
    return {"message": msg, "user": auth.get_user(user["username"])}


@app.post("/estimates", status_code=201)
def create_estimate(body: EstimateIn, user: dict = Depends(active_user)):
    fwd = service.run_estimate(body.facility, body.horizon_days, body.loadshedding, body.tariff, body.own_avg_kwh)
    est_id = auth.save_estimate(user["username"], body.facility, body.horizon_days, body.loadshedding, body.tariff,
                                body.own_avg_kwh, fwd["consumption_kwh_forecast"].sum(),
                                fwd["consumption_kwh_forecast"].max(), fwd["estimated_cost_zmw"].sum())
    auth.log_activity(user["username"], "estimate",
                      f"{body.facility}, {body.horizon_days}d, tariff {body.tariff}, loadshed={body.loadshedding} (API)")
    return _estimate_payload(est_id, _ref(est_id), body, fwd)


@app.get("/estimates")
def list_estimates(user: dict = Depends(active_user)):
    rows = auth.get_estimates(user["username"])
    return [{"id": r["id"], "ref": _ref(r["id"]), "ts": r["ts"], "facility": r["facility"],
             "horizon_days": r["horizon_days"], "loadshedding": bool(r["loadshedding"]), "tariff": r["tariff"],
             "own_avg_kwh": r["own_avg_kwh"], "total_kwh": r["total_kwh"], "peak_kwh": r["peak_kwh"],
             "total_cost_zmw": r["total_cost"]} for r in rows]


def _find_estimate(est_id: int, user: dict) -> dict:
    rows = auth.get_estimates(None if user["role"] == "admin" else user["username"], limit=100000)
    for r in rows:
        if r["id"] == est_id:
            return r
    raise HTTPException(404, "Estimate not found.")


@app.get("/estimates/{est_id}")
def get_estimate(est_id: int, user: dict = Depends(active_user)):
    r = _find_estimate(est_id, user)
    req = EstimateIn(facility=r["facility"], horizon_days=r["horizon_days"], loadshedding=bool(r["loadshedding"]),
                     tariff=r["tariff"], own_avg_kwh=r["own_avg_kwh"])
    fwd = service.run_estimate(req.facility, req.horizon_days, req.loadshedding, req.tariff, req.own_avg_kwh)
    return _estimate_payload(est_id, _ref(est_id), req, fwd)


@app.get("/estimates/{est_id}/pdf")
def estimate_pdf(est_id: int, user: dict = Depends(active_user)):
    r = _find_estimate(est_id, user)
    owner = auth.get_user(r["username"]) or user
    fwd = service.run_estimate(r["facility"], r["horizon_days"], bool(r["loadshedding"]), r["tariff"], r["own_avg_kwh"])
    pdf = report.build_bill_pdf(
        owner, {"facility": r["facility"], "horizon": r["horizon_days"], "loadshed": bool(r["loadshedding"]),
                "tariff": r["tariff"], "own_avg": r["own_avg_kwh"]},
        fwd, reference=_ref(est_id), is_synthetic=service.IS_SYNTHETIC)
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{_ref(est_id)}_cost_estimate.pdf"'})


@app.post("/review-requests", status_code=201)
def create_review_request(body: ReviewRequestIn, user: dict = Depends(active_user)):
    if body.estimate_id is not None:
        _find_estimate(body.estimate_id, user)   # must be the caller's own estimate
    new_id = _check(auth.create_review_request(user["username"], body.facility_name, body.facility_type,
                                               body.location, body.contact, body.subject, body.message,
                                               body.estimate_id))
    auth.log_activity(user["username"], "review_request", f"#{new_id}: {body.subject[:60]} (API)")
    notify.send_admin_notification(
        f"[Forecasting prototype] New facility review request #{new_id}",
        f"From: {user['full_name']} (@{user['username']})\nFacility: {body.facility_name}\n"
        f"Contact: {body.contact}\n\nSubject: {body.subject}\n\n{body.message}")
    return {"id": new_id}


@app.get("/review-requests")
def my_review_requests(user: dict = Depends(active_user)):
    return {"unread_replies": auth.count_unread_replies(user["username"]),
            "requests": auth.list_review_requests(username=user["username"])}


@app.post("/review-requests/mark-read")
def mark_read(user: dict = Depends(active_user)):
    auth.mark_replies_read(user["username"])
    return {"unread_replies": 0}


# --------------------------------------------------------------------------- admin

@app.get("/admin/forecast")
def admin_forecast(facility: Facility = "school", days: int = Query(7, ge=1, le=30), loadshedding: bool = False,
                   tariff: float = Query(2.5, ge=0.1, le=20), _: dict = Depends(admin_user)):
    fwd = service.run_estimate(facility, days, loadshedding, tariff, 0)
    return _estimate_payload(0, "PLAN", EstimateIn(facility=facility, horizon_days=days, loadshedding=loadshedding,
                                                    tariff=tariff), fwd)


@app.get("/admin/models")
def admin_models(facility: Facility = "school", days: int = Query(90, ge=7, le=90), _: dict = Depends(admin_user)):
    return service.model_summary(facility, days)


@app.get("/admin/monitoring")
def admin_monitoring(facility: Facility = "school", threshold_pct: float = Query(15, ge=1, le=100),
                     _: dict = Depends(admin_user)):
    return service.monitoring(facility, threshold_pct)


@app.get("/admin/users")
def admin_users(_: dict = Depends(admin_user)):
    return auth.list_users()


@app.post("/admin/users", status_code=201)
def admin_create_user(body: NewUserIn, admin: dict = Depends(admin_user)):
    msg = _check(auth.create_user(body.username, body.temporary_password, body.full_name, role=body.role,
                                  organisation=body.organisation, must_change=True))
    auth.log_activity(admin["username"], "create_user", f"{body.username} ({body.role}) via API")
    return {"message": msg}


@app.patch("/admin/users/{username}")
def admin_patch_user(username: str, body: UserPatchIn, admin: dict = Depends(admin_user)):
    msgs = []
    if body.active is not None:
        msgs.append(_check(auth.set_active(username, body.active)))
    if body.role is not None:
        msgs.append(_check(auth.set_role(username, body.role)))
    if not msgs:
        raise HTTPException(400, "Nothing to update.")
    auth.log_activity(admin["username"], "update_user", f"{username}: {' '.join(msgs)}")
    return {"message": " ".join(msgs)}


@app.post("/admin/users/{username}/reset-password")
def admin_reset_password(username: str, body: ResetPasswordIn, admin: dict = Depends(admin_user)):
    if auth.get_user(username) is None:
        raise HTTPException(404, "User not found.")
    msg = _check(auth.change_password(username, body.temporary_password, must_change=True))
    auth.log_activity(admin["username"], "reset_password", username)
    return {"message": msg + " The user must choose a new password at next login."}


@app.delete("/admin/users/{username}")
def admin_delete_user(username: str, admin: dict = Depends(admin_user)):
    msg = _check(auth.delete_user(username))
    auth.log_activity(admin["username"], "delete_user", username)
    return {"message": msg}


@app.get("/admin/estimates")
def admin_estimates(limit: int = Query(200, ge=1, le=2000), _: dict = Depends(admin_user)):
    return [dict(r, ref=_ref(r["id"])) for r in auth.get_estimates(None, limit)]


@app.get("/admin/review-requests")
def admin_review_requests(status: Optional[Literal["new", "in_progress", "resolved"]] = None,
                          _: dict = Depends(admin_user)):
    return {"open_count": auth.count_open_requests(), "requests": auth.list_review_requests(status=status)}


@app.post("/admin/review-requests/{request_id}/reply")
def admin_reply(request_id: int, body: ReplyIn, admin: dict = Depends(admin_user)):
    msg = _check(auth.update_review_request(request_id, body.status, body.reply, admin["username"]))
    auth.log_activity(admin["username"], "review_reply", f"#{request_id} -> {body.status} (API)")
    return {"message": msg}


@app.get("/admin/activity")
def admin_activity(limit: int = Query(200, ge=1, le=2000), _: dict = Depends(admin_user)):
    return auth.get_activity(limit)


@app.get("/admin/settings")
def admin_get_settings(_: dict = Depends(admin_user)):
    return {"default_tariff": float(auth.get_setting("default_tariff") or 2.5),
            "allow_registration": auth.get_setting("allow_registration") == "1"}


@app.put("/admin/settings")
def admin_put_settings(body: SettingsIn, admin: dict = Depends(admin_user)):
    if body.default_tariff is not None:
        auth.set_setting("default_tariff", f"{body.default_tariff:.2f}")
    if body.allow_registration is not None:
        auth.set_setting("allow_registration", "1" if body.allow_registration else "0")
    auth.log_activity(admin["username"], "settings", "updated via API")
    return admin_get_settings(admin)
